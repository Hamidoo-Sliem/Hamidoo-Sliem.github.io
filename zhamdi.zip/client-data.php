<?php  require_once "inc/config.inc.php"; ?>
<?php  require_once "inc/languages.php"; ?>
<?php 
$titx="SAIF Admin | {$a[159][$lang]}";
$bred="{$a[159][$lang]}";
$tags="";
$pgx=17;
 ?>
<?php
if(isset($_REQUEST['downxsl'])){
$file = tempnam("tmp", "zip");

$zip = new ZipArchive();

// Zip will open and overwrite the file, rather than try to read it. 
$zip->open($file, ZipArchive::OVERWRITE);
$zip->addFile('tpl/client-data.xlsx');
$zip->close();
// Stream the file to the client 
header("Content-Type: application/zip"); 
header("Content-Length: " . filesize($file)); 
header("Content-Disposition: attachment; filename=\"client-data".date('d-m-Y g-i-s').".zip\""); 
readfile($file); 
unlink($file);
//unlink('tpl/client-data.xlsx');
exit;
}
?>
<?php require_once "inc/tcpdf/examples/tcpdf_include.php"; ?>
<?php
if(isset($_REQUEST['downpdf'])){
ob_start(); 
@$noteg=$_REQUEST['noteg'];
@$nat=$_REQUEST['nat'];
@$typ=implode(',',$_REQUEST['typ']);
@$stat=$_REQUEST['stat'];
@$ara=$_REQUEST['ar2'];
 @$ar=$_REQUEST['ar'];
@$certificates=$_REQUEST['certificates'];
@$lng=$_REQUEST['lng'];	
$pdf = new TCPDF(PDF_PAGE_ORIENTATION, PDF_UNIT, PDF_PAGE_FORMAT, true, 'UTF-8', false);
$pdf->SetPrintHeader(false);
$pdf->SetPrintFooter(false);

$pdf->SetMargins(PDF_MARGIN_LEFT, 0.5, 18);

// set auto page breaks
$pdf->SetAutoPageBreak(TRUE, PDF_MARGIN_BOTTOM);
$lg = Array();
$lg['a_meta_charset'] = 'UTF-8';
$lg['a_meta_dir'] = 'rtl';
$lg['a_meta_language'] = 'fa';
$lg['w_page'] = 'page';
$pdf->setLanguageArray($lg);
$pdf->AddPage("L"); 
$pdf->setRTL(true);
$pdf->SetFont('times', '', 10);
$pdf->Ln();
$q="SELECT NatTp,CertsHlds.CrtOID AS bnkID,CertsHlds.BrID AS brc,CorrsAdr,Custs.CustID AS ctid ,CustTp,NatID_RegNum,CertsHlds.CoddyID AS codd,Adr,AdrEn,StatNm{$lang} AS sts,CtryNm{$lang} AS cnt,CertNm{$lang} AS cn,CertTrs.CertContMok AS mok,CustNm{$lang} AS cname,CertPr FROM Custs 
INNER JOIN Ctrys USING(CtryID) 
INNER JOIN CertsHlds ON CertsHlds.CustID=Custs.CustID 
INNER JOIN Stats ON Stats.StatID=CertsHlds.StatID 
LEFT JOIN CertTrs ON (CertTrs.CustID=Custs.CustID AND CertsHlds.CertID=CertTrs.CertID AND CertTrs.CustID=CertsHlds.CustID AND CertTrs.CoddyID = CertsHlds.CoddyID) 
INNER JOIN Certs ON (CertTrs.CertID=Certs.CertID AND CertsHlds.CertID=Certs.CertID) WHERE TRUE";	
if (isset($noteg) ){ 
$q.=" AND CtryID <>1";
}else if (isset($nat) and $nat !='all') {
$q.=" AND CtryID ='$nat'";	
}
if (isset($typ)){
$q.=" AND CustTp IN($typ)";
}
if (isset($stat) and $stat !='all'){
$q.=" AND Stats.StatID='$stat'";
}
if (isset($ar) and $ar != -1){
$q.=" AND CertsHlds.GovnID ='$ar'";
}
if (isset($ara) and $ara != -1){
$q.=" AND CertsHlds.RgnID ='$ara'";
}
if (isset($certificates) and $certificates != 'all'){
$q.=" AND CertTrs.CertID ='$certificates'";
}
$res=mysql_query($q) or die (mysql_error());
if(mysql_num_rows($res) >=1){
$html22 ="<div style=\"text-align:left\">
<img src=\"img/logo.png\"  width=\"80\" height=\"50\" border=\"0\" />
</div><br>
<table  cellspacing=\"0\" cellpadding=\"4\" style=\"border:1px solid #ccc;\">
<tr align=\"center\" valign=\"middle\" bgcolor=\"#3C8DBC\" style=\"color:#fff;\">
<td>{$a[41][$lng]}</td>
<td>{$a[206][$lng]}</td>
<td>{$a[213][$lng]}</td>
<td>{$a[3309][$lang]} / {$a[3304][$lang]}</td>
<td>{$a[212][$lng]}</td>
<td>{$a[215][$lng]}</td>
<td>{$a[217][$lng]}</td>
<td>{$a[68][$lng]}</td>
<td>{$a[78][$lng]}</td>
<td>{$a[80][$lng]}</td>
</tr>";
while($r=mysql_fetch_array($res)) {
	  if($r['CustTp']=='طبيعي'){
           $tp= $a[207][$lang];
       }else{
           $tp=  $a[208][$lang];
	   }
	   if($r['NatTp'] == 1){
	 $titx=$a[3312][$lang];
   } else if($r['NatTp'] == 2){
	$titx=$a[3310][$lang];
 }  else {
	 $titx=$a[3311][$lang];
 }
    if($lang=='Ar'){
    $adrss=$r['Adr'];
	}else {
   $adrss=$r['AdrEn'];
	}
$tots=number_format($r['mok'] * $r['CertPr'],2);
$html22.="<tr align=\"center\" valign=\"middle\" bgcolor=\"#F3F4F5\" style=\"color:#000;\">
<td>{$r['cname']}</td>
<td>{$tp}</td>
<td>{$r['cnt']}</td>
<td>{$r['NatID_RegNum']} / {$titx}</td>
<td>{$r['codd']}</td>
<td>{$adrss}</td>
<td>{$r['sts']}</td>
<td>{$r['cn']}</td>
<td>{$r['mok']}</td>
<td>{$tots}</td>
</tr>";
}
$html22.="</table>";
$pdf->writeHTML($html22, true, false, true, false, '');
$pdf->lastPage();
$pdf->Output('tpl/clientdata.pdf', 'I');
}
}
?>
<?php require_once "inc/header.inc.php"; ?>
<?php require_once "inc/Classes/PHPExcel.php"; ?>
        <div class="wrapper row-offcanvas row-offcanvas-left">
            <!-- Left side column. contains the logo and sidebar -->
            <?php require_once "inc/sidebar.inc.php"; ?>
            <!-- Right side column. Contains the navbar and content of the page -->
            <aside class="right-side">
                <!-- Content Header (Page header) -->
                <section class="content-header">
                    <h1>
                        <?=$bred?>
                        <small><?=$tags?></small>
                    </h1>
                </section>

                <!-- Main content -->
                <section class="content">
 <form action="" method="get" id="custmx" class="cusdata">
  <input type="hidden" name="lang" value="<?=$lang;?>">
<table width="794"  border="0" cellpadding="5" cellspacing="5" class="arabic">
  <tr>
     <td width="199"><?=$a[213][$lang] ;?></td>
    <td width="222">
     <select name="nat"  class="form-control">
    <option value="all"><?=$a[164][$lang];?></option>
   <?php
    $q="SELECT CtryID,CtryNm{$lang} AS nat FROM Ctrys WHERE  Is_Canc=0";
	 $res=mysql_query($q) or die (mysql_error());
	while($rr=mysql_fetch_array($res)) { 
  ?>  
      <option value="<?=$rr['CtryID'];?>"><?=$rr['nat'] ;?> </option>
   <?php } ?>
    </select>
    </td>
   <td colspan="2">
      <input type="checkbox" name="noteg" class="form-control2" value="1" >&nbsp;&nbsp;
       <?=$a[158][$lang];?>
      </td>
  </tr>
  <tr>
    <td width="199" ><?=$a[157][$lang] ;?></td>
  <td >
      <input type="checkbox" name="typ[]" class="form-control2" value="'طبيعي'" > &nbsp; <?=$a[207][$lang] ;?>  &nbsp;&nbsp;
      <input type="checkbox" name="typ[]" class="form-control2" value="'إعتباري'" >&nbsp;&nbsp;  <?=$a[208][$lang] ;?>
 </td>
  </tr>
    <tr >
    
     <td  align="right"><?=$a[201][$lang];?></td>
    <td >
    <?php if(isset($err[4])) {  echo "<span class='dirr' style='color:#FF3333'>&bull; {$err[4]}</span>";} ?>
    <select name="ar" class="form-control" id="govern">
    <option value="-1"><?=$a[164][$lang];?></option>
   <?php
    $q="SELECT GovnID,GovnNm{$lang} AS ar FROM Govns WHERE Is_Acv=1 AND Is_Canc=0 ORDER BY GovnNm{$lang} ASC";
	$res=mysql_query($q) or die (mysql_error());
	while($rr=mysql_fetch_array($res)) {
  ?>  
      <option value="<?=$rr['GovnID'];?>"> <?=$rr['ar'];?> </option>
      <?php } ?>
    </select>
    </td>
    <td  align="right"><?=$a[3315][$lang];?></td> 
    <td>
    <?php if(isset($err[4])) {  echo "<span class='dirr' style='color:#FF3333'>&bull; {$err[4]}</span>";} ?>
    <select name="ar2" class="form-control" id="regn" disabled >
    </select>
    </td>  
    </tr>
    <tr >
      <td ><?=$a[217][$lang] ;?></td>
    <td width="222">
     <select name="stat"  class="form-control">
    <option value="all"><?=$a[164][$lang];?></option>
   <?php
    $q="SELECT StatID,StatNm{$lang} AS sta FROM Stats WHERE  Is_Canc=0 AND StatID IN(1,2,3,4)";
	$res=mysql_query($q) or die (mysql_error());
	while($rr=mysql_fetch_array($res)) {
  ?>  
      <option value="<?=$rr['StatID'];?>"><?=$rr['sta'] ;?> </option>
      <?php } ?>
    </select>
    </td>
    
  <td ><?=$a[68][$lang] ;?></td>
    <td width="188">
    <select name="certificates"  class="form-control">
    <option value="all"><?=$a[164][$lang];?></option>
  <?php
    $q="SELECT CertID,CertNm{$lang} AS bx FROM Certs";
	$res=mysql_query($q) or die (mysql_error());
	while($rr=mysql_fetch_array($res)) {
  ?>  
      <option value="<?=$rr['CertID'];?>"><?=$rr['bx'] ;?> </option>
      <?php } ?>
    </select>
    </td>    
   </tr> 
    
    <tr>
    <td width="199" ><?=$a[161][$lang] ;?></td>
    <td >
      <input type="radio" name="lng" class="form-control2" value="Ar" <?php if($lang=='Ar'){?> checked <?php } ?> > &nbsp; <?=$a[162][$lang] ;?>  &nbsp;&nbsp;
      <input type="radio" name="lng" class="form-control2" value="En" <?php if($lang=='En'){?> checked <?php } ?>>&nbsp;&nbsp;  <?=$a[163][$lang] ;?>
      </td>
  </tr>
  <tr>
  <td align="right" colspan="4"><input type="submit" id="xjcdat" name="submit"  class="btn btn-primary" value="<?=$a[160][$lang];?>" <?php if($insx==0) { ?> disabled <?php } ?>>  <input type="reset" name="reset"  class="btn btn-primary" value="<?=$a[32][$lang];?>">
  <input type="submit" name="downpdf" class="btn btn-primary" value="PDF">
<?php 
 if(isset($_REQUEST['submit'])){ ?> 
<input type="submit" name="downxsl" class="btn btn-primary" value="<?=$a[165][$lang];?>">

<a href="javascript:window.print() ;" <?php if($prtx==0) { ?> onClick="alert('ليس لديك الصلاحية للطباعة');return false;" <?php } ?>>
<i class="btn btn-info btn"><?=$a[155][$lang];?> </i>
</a>
<?php } ?>
  </td>
  </tr>
   </table>
 </form>
 <br>

<?php 
 if (isset($_GET["page"])) { $page  = (int)$_GET["page"]; } else { $page=1; };
if ($page < 1) $page = 1;
$numberOfPages = 4;
$resultsPerPage = 10;

if(isset($_REQUEST['submit'])){
	
     @$sumit=$_REQUEST['submit'];
	 @$noteg=$_REQUEST['noteg'];
 	  @$nat=$_REQUEST['nat'];
	  @$typ=implode(',',$_REQUEST['typ']);
	  @$stat=$_REQUEST['stat'];
	   @$ar=$_REQUEST['ar'];
	  @$ara=$_REQUEST['ar2'];
	  @$certificates=$_REQUEST['certificates'];
	  @$lng=$_REQUEST['lng'];
	
?>
<?php 	  
$q="SELECT NatTp,CertsHlds.CrtOID AS bnkID,CertsHlds.BrID AS brc,CorrsAdr,Custs.CustID AS ctid ,CustTp,NatID_RegNum,CertsHlds.CoddyID AS codd,Adr,AdrEn,StatNm{$lang} AS sts,CtryNm{$lang} AS cnt,CertNm{$lang} AS cn,CertTrs.CertContMok AS mok,CustNm{$lang} AS cname,CertPr FROM Custs 
INNER JOIN Ctrys USING(CtryID) 
INNER JOIN CertsHlds ON CertsHlds.CustID=Custs.CustID 
INNER JOIN Stats ON Stats.StatID=CertsHlds.StatID 
LEFT JOIN CertTrs ON (CertTrs.CustID=Custs.CustID AND CertsHlds.CertID=CertTrs.CertID AND CertTrs.CustID=CertsHlds.CustID AND CertTrs.CoddyID = CertsHlds.CoddyID) 
INNER JOIN Certs ON (CertTrs.CertID=Certs.CertID AND CertsHlds.CertID=Certs.CertID) WHERE TRUE";
$qus="?lang=$lang";
if (isset($noteg) ){
$qus.="&nat=$nat";
$q.=" AND CtryID <>1";
}else if (isset($nat) and $nat !='all') {
$qus.="&nat=$nat";
$q.=" AND CtryID ='$nat'";	
}
if (isset($typ)){
$qus.="&typ=$typ";
$q.=" AND CustTp IN($typ)";
}
if (isset($stat) and $stat !='all'){
$qus.="&stat=$stat";
$q.=" AND Stats.StatID='$stat'";
}
if (isset($ar) and $ar != -1){
$qus.="&ar=$ar";
$q.=" AND CertsHlds.GovnID ='$ar'";
}
if (isset($ara) and $ara != -1){
$qus.="&ara=$ara";
$q.=" AND CertsHlds.RgnID ='$ara'";
}
if (isset($certificates) and $certificates != 'all'){
$qus.="&certificates=$certificates";
$q.=" AND CertTrs.CertID ='$certificates'";
}
$qus.="&submit=$sumit&lng=$lng";
$z=2;	
	$total_records = mysql_num_rows(mysql_query($q));   // important to get number of rows is conditions and limit

	//break records into pages
	$totalPages = ceil($total_records / $resultsPerPage);
	
	//get starting position to fetch the records
	//if ($page > $totalPages) $page = $totalPages;
$startResults = ($page - 1) * $resultsPerPage;

	$q.=" LIMIT {$startResults},{$resultsPerPage}";
$res=mysql_query($q) or die (mysql_error());
if(mysql_num_rows($res) >=1){
?>

<?php
$halfPages = floor($numberOfPages / 2);
$range = array('start' => 1, 'end' => $totalPages);
$isEven = ($numberOfPages % 2 == 0);
$atRangeEnd = $totalPages - $halfPages;

if($isEven) $atRangeEnd++;

if($totalPages > $numberOfPages)
{
	if($page <= $halfPages)
		$range['end'] = $numberOfPages;
	elseif ($page >= $atRangeEnd)
		$range['start'] = $totalPages - $numberOfPages + 1;
	else
	{
		$range['start'] = $page - $halfPages;
		$range['end'] = $page + $halfPages;
		if($isEven) $range['end']--;
	}
}
echo "<div class='cpp'> {$a[3274][$lang]} " .$page. " {$a[3275][$lang]} " . $totalPages ."</div>";
?>
<div id="pager">
<?php
if($page > 1) {
	$pg=$page - 1;
?>
 <a href="<?=$qus;?>&page=1" class="laq"> &laquo;&laquo;</a>
<a href="<?=$qus;?>&page=<?=$pg;?>" class="laq">&laquo;</a>
<?php
}

for ($i = $range['start']; $i <= $range['end']; $i++)
{
	if($i == $page) {
		?>
		<a href="<?=$qus;?>&page=<?=$i;?>" class="acvx"><?=$i;?></a>
        <?php
	}else {
		?>
		<a href="<?=$qus;?>&page=<?=$i;?>" class="forx"><?=$i;?></a>
        <?php
	}
}
if ($page < $totalPages) { 
$pg=$page + 1;
?>
<a href="<?=$qus;?>&page=<?=$pg;?>" class="raq">&raquo;</a>
 <a href="<?=$qus;?>&page=<?=$totalPages;?>" class="raq"> &raquo;&raquo;</a>
    <?php
}
?>
</div>

<table  border='0'  class='table table-bordered table-striped dataTable arabic3' style='font-size:12px;'>
  <tr>
     <td><?=$a[41][$lng];?></td>
     <td><?=$a[206][$lng];?></td>
      <td><?=$a[213][$lng];?></td>
     <td><?=$a[3309][$lang];?> / <?=$a[3304][$lang];?></td>
     <td><?=$a[212][$lng];?></td>
     <td><?=$a[215][$lang];?></td>
     <td><?=$a[216][$lang];?></td>
     <td><?=$a[217][$lng];?></td>
	 <td><?=$a[68][$lng];?></td>
     <td><?=$a[78][$lng];?></td>
     <td><?=$a[80][$lng];?></td>
  </tr> 
  <?php 
$objPHPExcel = new PHPExcel();
$objPHPExcel->setActiveSheetIndex(0)
            ->setCellValue('A1', $a[41][$lng])
			->setCellValue('B1', $a[206][$lng])
		    ->setCellValue('C1', $a[213][$lng])
		   ->setCellValue('D1', $a[3309][$lng] . '/'. $a[3304][$lng])
			->setCellValue('E1', $a[212][$lng])
            ->setCellValue('F1', $a[215][$lng])
			->setCellValue('G1', $a[217][$lng])
			->setCellValue('H1', $a[68][$lng])			
			->setCellValue('I1', $a[78][$lng])			
			->setCellValue('J1', $a[80][$lng]);

while($r=mysql_fetch_array($res)) {
	
$BR=$r['brc'];
$BNK=$r['bnkID'];
$qs=mysql_query("SELECT CrtONmAr,BrNmAr,CrtONmEn,BrNmEn FROM CrtOwns INNER JOIN OwnsBrs ON CrtOwns.CrtOID=OwnsBrs.CrtOID WHERE  CrtOwns.CrtOID='$BNK' AND BrID='$BR'") or die(mysql_error());
$rsq=mysql_fetch_array($qs);
$bknam=$rsq['CrtONm'.$lang];
$brnam= $rsq['BrNm'.$lang];
	
	 if($r['CorrsAdr']==1){
		 $adr= $bknam ."-" . $brnam ;
           $ca="<font color=\"#55a51c\">{$a[221][$lang]}</font>" ;
       }else{
           $ca="<font color=\"#f00\">{$a[222][$lang]}</font>";
		   if($lang == 'Ar') {
		       $adr=$r['Adr'];
		   } else {
			   $adr=$r['AdrEn'];
		   }
	   }
	
	  if($r['CustTp']=='طبيعي'){
           $tp= $a[207][$lang];
       }else{
           $tp=  $a[208][$lang];
	   }
	   
	if($r['NatTp'] == 1){
	 $titx=$a[3312][$lang];
   } else if($r['NatTp'] == 2){
	$titx=$a[3310][$lang];
 }  else {
	 $titx=$a[3311][$lang];
 }
?>	  
 <tr>
        <td style="position:relative;cursor:pointer;" class="menx"><b><u><?=$r['cname'];?></u></b>
       <div class="opt" style="position:absolute;width:210px;height:auto;background-color:#fff;box-shadow:1px 1px 2px #000;padding:8px 10px ; z-index:100;display:none;">

<a href="customers.SAIF?lang=<?=$lang;?>&idx=<?=base64_encode($r['ctid']);?>" style="color:#000;font-size:14px;display:block;" onMouseOver="$(this).css('background-color','#EBEBEB');" onMouseOut="$(this).css('background-color','#FFFF');" class="updx">
<i class="glyphicon glyphicon-edit" style="color:#0066CC;margin-right:7px;"></i><?=$a[33][$lang];?>
</a>
<a href="certificateHolders.SAIF?lang=<?=$lang;?>&brn=<?=base64_encode($r['ctid']);?>&zzz=<?=base64_encode($r['bnkID']);?>" style="color:#000;font-size:14px;display:block;" onMouseOver="$(this).css('background-color','#EBEBEB');" onMouseOut="$(this).css('background-color','#FFFF');" >
<i class="glyphicon glyphicon-search" style="color:#0066CC;margin-right:7px;"></i><?=$a[66][$lang];?>
</a>

<a href="bankstatement.SAIF?lang=<?=$lang;?>&brn=<?=base64_encode($r['ctid']);?>" style="color:#000;font-size:14px;display:block;" onMouseOver="$(this).css('background-color','#EBEBEB');" onMouseOut="$(this).css('background-color','#FFFF');">
<i class="glyphicon glyphicon-paperclip" style="color:#0066CC;margin-right:7px;"></i><?=$a[3270][$lang];?>
</a>

<a href="totstatement.SAIF?lang=<?=$lang;?>&brn=<?=base64_encode($r['ctid']);?>" style="color:#000;font-size:14px;display:block;" onMouseOver="$(this).css('background-color','#EBEBEB');" onMouseOut="$(this).css('background-color','#FFFF');">
<i class="glyphicon glyphicon-paperclip" style="color:#0066CC;margin-right:7px;"></i><?=$a[3271][$lang];?>
</a>

    </div>
    </td>       
    <td><?=$tp;?></td>
    <td><?=$r['cnt'];?></td>
    <td><?=$r['NatID_RegNum'];?> <br> <small> [<?=$titx;?>] </small></td>
    <td><?=$r['codd'];?></td>
     <td><?=$adr?></td>
    <td><?=$ca;?></td>
    <td><?=$r['sts'];?></td>
	<td><?=$r['cn'];?></td>
 <td><?=$r['mok'];?></td>
 <td><?=number_format($r['CertPr'] * $r['mok'],2);?></td>
</tr>
<?php
$tots=number_format($r['mok'] * $r['CertPr'],2);
?>
 <?php
 
if($lang == 'Ar'){
$adrs='Adr';  
} else {
$adrs='AdrEn';
}
$objPHPExcel->setActiveSheetIndex(0)
            ->setCellValue('A'.$z, $r['cname'])
			->setCellValue('B'.$z, $tp)
			->setCellValue('C'.$z, $r['cnt'])
			->setCellValue('D'.$z, $r['NatID_RegNum'] .' / '. $titx)
			->setCellValue('E'.$z, $r['codd'])
            ->setCellValue('F'.$z, $r[$adrs])
			->setCellValue('G'.$z, $r['sts'])
			->setCellValue('H'.$z, $r['cn'])
			->setCellValue('I'.$z, $r['mok'])
			->setCellValue('J'.$z, $tots);
$objPHPExcel->getActiveSheet()->getStyle('A'.$z.':O'.$z)->getFill()->setFillType(PHPExcel_Style_Fill::FILL_SOLID);
$objPHPExcel->getActiveSheet()->getStyle('A'.$z.':O'.$z)->getFill()->getStartColor()->setARGB('60F3F4F5');
$z++;
 } 
?>
</table>
<?php
$objPHPExcel->getActiveSheet()->getStyle('A1:O1')->getFont()->setName('Courier');
$objPHPExcel->getActiveSheet()->getStyle('A1:O1')->getFont()->setSize(11);
$objPHPExcel->getActiveSheet()->getStyle('A1:O1')->getFont()->setBold(true);
$objPHPExcel->getActiveSheet()->getStyle('A1:O1')->getFont()->getColor()->setARGB(PHPExcel_Style_Color::COLOR_WHITE);

$objPHPExcel->getActiveSheet()->getStyle('A1:O1')->getFill()->setFillType(PHPExcel_Style_Fill::FILL_SOLID);
$objPHPExcel->getActiveSheet()->getStyle('A1:O1')->getFill()->getStartColor()->setARGB('803C8DBC');

$objPHPExcel->getActiveSheet()->getColumnDimension('A')->setAutoSize(true);
$objPHPExcel->getActiveSheet()->getColumnDimension('B')->setAutoSize(5);
$objPHPExcel->getActiveSheet()->getColumnDimension('C')->setAutoSize(5);
$objPHPExcel->getActiveSheet()->getColumnDimension('D')->setAutoSize(5);
$objPHPExcel->getActiveSheet()->getColumnDimension('E')->setAutoSize(12);
$objPHPExcel->getActiveSheet()->getColumnDimension('F')->setAutoSize(12);
$objPHPExcel->getActiveSheet()->getColumnDimension('G')->setAutoSize(12);
$objPHPExcel->getActiveSheet()->getColumnDimension('H')->setAutoSize(12);
$objPHPExcel->getActiveSheet()->getColumnDimension('I')->setAutoSize(12);
$objPHPExcel->getActiveSheet()->getColumnDimension('J')->setAutoSize(12);
$objPHPExcel->getActiveSheet()->getColumnDimension('K')->setAutoSize(12);
$objPHPExcel->getActiveSheet()->getColumnDimension('L')->setAutoSize(12);
$objPHPExcel->getActiveSheet()->getColumnDimension('M')->setAutoSize(12);
$objPHPExcel->getActiveSheet()->getColumnDimension('N')->setAutoSize(12);
$objPHPExcel->getActiveSheet()->getColumnDimension('O')->setAutoSize(12);

$callStartTime = microtime(true);
$objWriter = PHPExcel_IOFactory::createWriter($objPHPExcel, 'Excel2007');
$objWriter->save(str_replace('.php', '.xlsx', 'tpl/client-data.php'));
$callEndTime = microtime(true);
$callTime = $callEndTime - $callStartTime;
?>

<?php
$halfPages = floor($numberOfPages / 2);
$range = array('start' => 1, 'end' => $totalPages);
$isEven = ($numberOfPages % 2 == 0);
$atRangeEnd = $totalPages - $halfPages;

if($isEven) $atRangeEnd++;

if($totalPages > $numberOfPages)
{
	if($page <= $halfPages)
		$range['end'] = $numberOfPages;
	elseif ($page >= $atRangeEnd)
		$range['start'] = $totalPages - $numberOfPages + 1;
	else
	{
		$range['start'] = $page - $halfPages;
		$range['end'] = $page + $halfPages;
		if($isEven) $range['end']--;
	}
}
echo "<div class='cpp'> {$a[3274][$lang]} " .$page. " {$a[3275][$lang]}  " .  $totalPages ."</div>";
?>
<div id="pager">
<?php
if($page > 1) {
	$pg=$page - 1;
?>
<a href="<?=$qus;?>&page=1" class="laq"> &laquo;&laquo;</a>
<a href="<?=$qus;?>&page=<?=$pg;?>" class="laq">&laquo;</a>
<?php
}

for ($i = $range['start']; $i <= $range['end']; $i++)
{
	if($i == $page) {
		?>
		<a href="<?=$qus;?>&page=<?=$i;?>" class="acvx"><?=$i;?></a>
        <?php
	}else {
		?>
		<a href="<?=$qus;?>&page=<?=$i;?>" class="forx"><?=$i;?></a>
        <?php
	}
}
if ($page < $totalPages) { 
$pg=$page + 1;
?>
<a href="<?=$qus;?>&page=<?=$pg;?>" class="raq">&raquo;</a>
<a href="<?=$qus;?>&page=<?=$totalPages;?>" class="raq"> &raquo;&raquo;</a>
<?php
}
?>
</div>
<?php
} else {
echo "<div  style=\"width:850px;margin:0px auto;text-align:center;clear:both;font-family:hamdyfont,Tahoma !important;\"><h3>{$a[3273][$lang]}</h3></div>";	
}
}
?>

                </section><!-- /.content -->
            </aside><!-- /.right-side -->
        </div><!-- ./wrapper -->
<?php require_once "inc/footer.inc.php"; ?>
