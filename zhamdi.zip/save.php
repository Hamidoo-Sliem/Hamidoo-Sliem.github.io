<?php

define('WP_USE_THEMES', true);
// Load the WordPress library.
require_once( dirname(__FILE__) . '/wp-load.php' );

	// Set up the WordPress query.
	wp();
	//echo admin_url( 'admin-ajax.php' ) ;
	//https://wpress.com/wp-admin/admin-ajax.php?action=save_ex
	//echo home_url('/');   //https://wpress.com/
	global $wpdb;
/*$reserved = $wpdb->get_results("SELECT *,STR_TO_DATE(start_time,'%h:%i %p') AS stime,STR_TO_DATE(end_time,'%h:%i %p') AS etime,STR_TO_DATE('6:30 PM','%h:%i %p') AS sxtime,STR_TO_DATE('8:00 PM','%h:%i %p') AS extime FROM wp_appointment WHERE 
 start_date = '2018-02-22' AND end_date = '2018-02-22' AND docId = '120'");
 
 foreach ( $reserved as $overlap ) {
	if ( (strtotime($overlap->sxtime) >= strtotime($overlap->stime)) && (strtotime($overlap->sxtime) <= strtotime($overlap->etime))) {
		echo "okk";
	} 
 }
	
	exit;*/
	//echo $userId = get_current_user_id();

if(!function_exists("clean")) {	
	function clean ($str) {
		$sauf = array("%","#",'"',"/","<",">","&","*","@","^","?","!","$","[","]","|","{","}","+","~","(",")");
		$repw = array(" "," "," "," "," "," "," "," "," "," "," "," "," "," "," "," "," "," "," "," "," "," ");
		$str=strip_tags(trim(stripslashes(str_replace($sauf,$repw,$str))));
		return $str;
	   }
}


$err = [];

if (is_uploaded_file ($_FILES['files']['tmp_name'])){
					if (preg_match("~\.(csv|xlsx|xls|xltx|xlt)$~i", $_FILES['files']['name'])){
						 $source = $_FILES['files']['tmp_name'];
						 $target =realpath(__DIR__)."/up/".$_FILES['files']['name'];
						 move_uploaded_file( $source, $target );
						 $ext = substr($_FILES['files']['name'], strripos($_FILES['files']['name'], '.')); 
						 $out=realpath(__DIR__)."/up/".uniqid(date('t-M')).$ext;
							      rename(realpath(__DIR__)."/up/".$_FILES['files']['name'],$out);	
						$lnk=ABSPATH . strstr($out,'up'); 
						chmod($lnk, 0777); 	 	 
					} else {
						$err[] = "the file not valid";
					}
			} else {
			    $err[] = "please select file";
	          }
			  
 if(empty($err)){
	
//set_include_path(get_include_path() . PATH_SEPARATOR . 'inc/Classes/');
//include 'PHPExcel/IOFactory.php';
include ABSPATH . 'inc/Classes/PHPExcel/IOFactory.php';
$inputFileName = $lnk; 
try {
	$objPHPExcel = PHPExcel_IOFactory::load($inputFileName);
} catch(Exception $e) {
	die('Error loading file "'.pathinfo($inputFileName,PATHINFO_BASENAME).'": '.$e->getMessage());
}
$sheetData = $objPHPExcel->getActiveSheet()->toArray(null,true,true,true);
$arrayCount = count($sheetData);
// patient

$tot=$arrayCount -1;
$insn=array();
$ed=array();
$skp=array();

$wpdb->query('SET AUTOCOMMIT=0');


for($i=2;$i<=$arrayCount;$i++){
	
//$wpdb->query('START TRANSACTION');

$start_d = $sheetData[$i]["A"];   
$end_d = $sheetData[$i]["D"];
$start_time = $sheetData[$i]["B"];   
$end_time = $sheetData[$i]["C"];
$rmk = clean($sheetData[$i]["E"]);
$cat = clean($sheetData[$i]["F"]);
$docID = $sheetData[$i]["G"];


$reserved = $wpdb->get_results("SELECT *,STR_TO_DATE(start_time,'%h:%i %p') AS stime,STR_TO_DATE(end_time,'%h:%i %p') AS etime,STR_TO_DATE('$start_time','%h:%i %p') AS sxtime,STR_TO_DATE('$end_time','%h:%i %p') AS extime FROM wp_appointment WHERE 
 start_date = '$start_d' AND end_date = '$end_d' AND docId = '$docID'");

if (empty($reserved) ) {

$ins = $wpdb->insert( 
	'wp_appointment', 
	array( 
	    'start_date' => $start_d, 
		'end_date' => $end_d,
		'start_time' => $start_time, 
		'end_time' => $end_time ,
		'status' => 'Pending' ,
		'patientId' => 75,
		'rmk' => $rmk, 
		'cat' => $cat ,
		'docId' => $docID
	)
);
if($ins !== false) {
	$wpdb->query('COMMIT'); 
	$insn[] = $i;
} else {
    $wpdb->query('ROLLBACK'); 
}


} else {		
		
foreach ( $reserved as $overlap ) {
	if ( (strtotime($overlap->sxtime) >= strtotime($overlap->stime)) && (strtotime($overlap->sxtime) <= strtotime($overlap->etime))) {
		$skp[]="&nbsp; &nbsp; - Row Number : ".$i."&nbsp;&nbsp;&nbsp; reserved (overlapped) before";	
		
	} else {
		
	if ($overlap->patientId == 75 ) {    // LOGIN USER
	if ($overlap->status == 'Pending' ) {
	$upd = $wpdb->update( 
	'wp_appointment', 
	array( 
	   'start_date' => $start_d, 
		'end_date' => $end_d,
		'start_time' => $start_time, 
		'end_time' => $end_time ,
		'status' => 'Pending' ,
		'patientId' => 75,
		'rmk' => $rmk, 
		'cat' => $cat ,
		'docId' => $docID
	),array( 'id' => $overlap->id )
);
if($udp !== false) {
	$wpdb->query('COMMIT'); 
	$ed[] = "&nbsp; &nbsp; - Row number  : ".$i."&nbsp;&nbsp;&nbsp; updated and overwrote";
} else {
    $wpdb->query('ROLLBACK'); 
}

	}else {
		$skp[]="&nbsp; &nbsp; - Row Number : ".$i."&nbsp;&nbsp;&nbsp; reserved before";	
	}
	
	}	// end if of login user
		
}  // end else of reserved

} // end foreach

}  // end if of reserved

} // end for loop

 } // end empty array
			  
		

$inserted = count($insn);
$chx=count($ed);
$sip=count($skp);


$flog=fopen("log/PLog.txt","w7t");
fwrite($flog,"\t\t".date('d/m/Y  g:i:s')."\r\n\n"); 
fwrite($flog,"\t\t Patient Upload Info \r\n\n"); 
fwrite($flog," Total Number : {$tot} \r\n"); 
fwrite($flog," Number of inserted rows : {$inserted} \r\n"); 

 fwrite($flog," Number of overwrite rows: {$chx} \r\n"); 
 if(!empty($ed)){
 foreach($ed as $eds) {
	fwrite($flog,strip_tags(str_replace('&nbsp;',' ',$eds))."\r\n"); 
 }
 }
fwrite($flog," Number of skipped rows : {$sip} \r\n"); 
 if(!empty($skp)) {
 foreach($skp as $sks) {
	fwrite($flog,strip_tags(str_replace('&nbsp;',' ',$sks))."\r\n"); 
 }
 }  
 fclose($flog);
 
