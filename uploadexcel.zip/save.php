<?php

// Load the WordPress library.
	require_once( dirname(__FILE__) . '/wp-load.php' );

	// Set up the WordPress query.
	wp();
	//echo admin_url( 'admin-ajax.php' ) ;
	//https://wpress.com/wp-admin/admin-ajax.php?action=save_ex
	//echo home_url('/');   //https://wpress.com/
	global $wpdb;
	
	//echo $userId = get_current_user_id();

if(!function_exists("clean")) {	
	function clean ($str) {
		$sauf = array("%","#",'"',"/","<",">","&","*","@","^","?","!","$","[","]","|","{","}","+","~","(",")");
		$repw = array(" "," "," "," "," "," "," "," "," "," "," "," "," "," "," "," "," "," "," "," "," "," ");
		$str=strip_tags(trim(stripslashes(str_replace($sauf,$repw,$str))));
		return $str;
	   }
}

$err = [];

if (is_uploaded_file ($_FILES['files']['tmp_name'])){
					if (preg_match("~\.(csv|xlsx|xls|xltx|xlt)$~i", $_FILES['files']['name'])){
						 $source = $_FILES['files']['tmp_name'];
						 $target =realpath(__DIR__)."/up/".$_FILES['files']['name'];
						 move_uploaded_file( $source, $target );
						 $ext = substr($_FILES['files']['name'], strripos($_FILES['files']['name'], '.')); 
						 $out=realpath(__DIR__)."/up/".uniqid(date('t-M')).$ext;
							      rename(realpath(__DIR__)."/up/".$_FILES['files']['name'],$out);	
							      chmod($out, 0777); 	  
						$lnk=strstr($out,'up'); 		 
					} else {
						$err[] = "the file not valid";
					}
			} else {
			    $err[] = "please select file";
	          }
			  
 if(empty($err)){
	
//set_include_path(get_include_path() . PATH_SEPARATOR . 'inc/Classes/');
//include 'PHPExcel/IOFactory.php';
include ABSPATH . 'inc/Classes/PHPExcel/IOFactory.php';
$inputFileName = $lnk; 
try {
	$objPHPExcel = PHPExcel_IOFactory::load($inputFileName);
} catch(Exception $e) {
	die('Error loading file "'.pathinfo($inputFileName,PATHINFO_BASENAME).'": '.$e->getMessage());
}
$sheetData = $objPHPExcel->getActiveSheet()->toArray(null,true,true,true);
$arrayCount = count($sheetData);
// patient

$tot=$arrayCount -1;
$insn=array();
$ed=array();
$skp=array();

$wpdb->query('SET AUTOCOMMIT=0');


for($i=2;$i<=$arrayCount;$i++){
	
//$wpdb->query('START TRANSACTION');

$start_time = $sheetData[$i]["A"];   
$end_time = $sheetData[$i]["B"];
$rmk = clean($sheetData[$i]["C"]);
$cat = clean($sheetData[$i]["D"]);
$docId = (int)$sheetData[$i]["E"];

$reserved = $wpdb->get_row("SELECT * FROM wp_appointment WHERE start_time = '$start_time' AND end_time = '$end_time'");

if ($reserved === NULL ) {

$ins = $wpdb->insert( 
	'wp_appointment', 
	array( 
		'start_time' => $start_time, 
		'end_time' => $end_time ,
		'rmk' => $rmk, 
		'cat' => $cat ,
		'attendee' => $docId
	)
);
if($ins !== false) {
	$wpdb->query('COMMIT'); 
	$insn[] = $i;
} else {
    $wpdb->query('ROLLBACK'); 
}


} else {
	$upd = $wpdb->update( 
	'wp_appointment', 
	array( 
		'start_time' => $start_time, 
		'end_time' => $end_time ,
		'rmk' => $rmk, 
		'cat' => $cat ,
		'attendee' => $docId
	),array( 'id' => $reserved->id )
);
if($udp !== false) {
	$wpdb->query('COMMIT'); 
	$ed[] = "&nbsp; &nbsp; - Row number  : ".$i."&nbsp;&nbsp;&nbsp; <small> updated and overwrote </small>";
} else {
    $wpdb->query('ROLLBACK'); 
}


}

}

 }
			  
	// $skp[]="&nbsp; &nbsp; - رقم الصف : ".$i."&nbsp;&nbsp;&nbsp; للعميل   [{$sheetData[$i]['A']}] &nbsp;&nbsp;&nbsp; <small> كود الفرع [{$sheetData[$i]['P']}] غير موجود</small>";	


$inserted = count($insn);
$chx=count($ed);
$sip=count($skp);


$flog=fopen("log/PLog.txt","w7t");
fwrite($flog,"\t\t".date('d/m/Y  g:i:s')."\r\n\n"); 
fwrite($flog,"\t\t Patient Upload Info \r\n\n"); 
fwrite($flog," Total Number : {$tot} \r\n"); 
fwrite($flog," Number of inserted rows : {$inserted} \r\n"); 

 fwrite($flog," Number of overwrite rows: {$chx} \r\n"); 
 if(!empty($ed)){
 foreach($ed as $eds) {
	fwrite($flog,strip_tags(str_replace('&nbsp;',' ',$eds))."\r\n"); 
 }
 }
fwrite($flog," Number of skipped rows : {$sip} \r\n"); 
 if(!empty($skp)) {
 foreach($skp as $sks) {
	fwrite($flog,strip_tags(str_replace('&nbsp;',' ',$sks))."\r\n"); 
 }
 }
 chmod("log/PLog.txt", 0777);  
 fclose($flog);