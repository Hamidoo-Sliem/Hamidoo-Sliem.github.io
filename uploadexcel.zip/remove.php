<?php

unlink($_FILES['files']['name']);