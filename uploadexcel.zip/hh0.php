<!DOCTYPE html>
<html>
<head>
    <title></title>
    <link rel="stylesheet" href="kendu/styles/kendo.common.min.css" />
    <link rel="stylesheet" href="kendu/styles/kendo.default.min.css" />
    <link rel="stylesheet" href="kendu/styles/kendo.default.mobile.min.css" />

    <script src="kendu/js/jquery.min.js"></script>
    <script src="kendu/js/kendo.all.min.js"></script>

</head>
<body>

        <div id="example">
            <div class="box">
                <h4>Information</h4>
                <p>
                    The Upload can be used as a drop-in replacement
                    for file input elements. This "synchronous" mode does not require
                    special handling on the server.
                </p>
            </div>
            <!--form method="post" action="save.php" enctype="multipart/form-data"-->
                <div class="demo-section k-content">
                    <input name="files" id="files" type="file" aria-label="files" />
                    <p style="padding-top: 1em; text-align: right">
                        <button type="submit" class="k-button k-primary">Submit</button>
                    </p>
                </div>
            <!--/form-->
            <script>
                $(document).ready(function() {
                    $("#files").kendoUpload({
                async: {
                    //saveUrl: "save.php",
					saveUrl: "https://wpress.com/wp-admin/admin-ajax.php?action=save_ex",
                    removeUrl: "remove.php",
                    //autoUpload: false    // use with form tag
					autoUpload: true 
                },
                validation: {  
                    allowedExtensions: [".csv", ".xlsx", ".xls", ".xltx", ".xlt"],
					maxFileSize: 10485760,   // in bytes
					//minFileSize: 300000
                },
                //cancel: onCancel,
                        complete: onComplete,
                        error: onError,
                        progress: onProgress,
                        //remove: onRemove,
                     //   select: onSelect,
                        success: onSuccess,
                      //  upload: onUpload
               // showFileList: false,
                //dropZone: ".dropZoneElement"
            });
			
			 function onProgress(e) {
                    alert("Upload progress :: " + e.percentComplete + "% ");
                }

            function onSuccess(e) {
				alert("Success (" + e.operation + ")");
			}
			
			 function onComplete(e) {
                    alert("Complete");
                }
			
			  function onError(e) {
				alert("Success (" + e.operation + ")");
			}
                });
            </script>
        </div>


</body>
</html>