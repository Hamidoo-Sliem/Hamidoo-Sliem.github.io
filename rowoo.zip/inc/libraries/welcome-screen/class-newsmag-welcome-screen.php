<?php
if ( ! defined( 'WPINC' ) ) {
	die;
}
/**
 * Welcome Screen Class
 */
class Newsmag_Welcome_Screen {

	/**
	 * Constructor for the welcome screen
	 */
	public function __construct() {
		/* create dashbord page */
		add_action( 'admin_menu', array( $this, 'newsmag_welcome_register_menu' ) );
		
		// custom post type  for slideshow
		//add_action( 'init', array( $this,'create_post_slideshow' ));
		
		// hamdi custom meta post for image upload
		add_action('add_meta_boxes', array( $this,'add_box'));
        add_action('save_post', array( $this,'save_postdata'), 1, 2);
        add_action( 'edit_page_form', array( $this, 'content_box' ));
		add_action('edit_post', array( $this,'save_postdata'), 1, 2);
		add_action('publish_post', array( $this,'save_postdata'), 1, 2);
		add_action('edit_page_form', array( $this,'save_postdata'), 1, 2);
		
		// hamdi add meta data for profile user in admin section
		add_action( 'show_user_profile', array( $this,'my_show_extra_profile_fields' ));
        add_action( 'edit_user_profile', array( $this,'my_show_extra_profile_fields' ));
		// for saving in profile
		add_action( 'personal_options_update', array( $this,'my_save_extra_profile_fields' ));
        add_action( 'edit_user_profile_update', array( $this,'my_save_extra_profile_fields' ));

		/* ctivation notice */
		add_action( 'load-themes.php', array( $this, 'newsmag_activation_admin_notice' ) );

		/* enqueue script and style for welcome screen */
		add_action( 'admin_enqueue_scripts', array( $this, 'newsmag_welcome_style_and_scripts' ) );

		/* ajax callback for dismissable required actions */
		add_action( 'wp_ajax_newsmag_dismiss_required_action', array(
			$this,
			'newsmag_dismiss_required_action_callback'
		) );
		add_action( 'wp_ajax_nopriv_newsmag_dismiss_required_action', array(
			$this,
			'newsmag_dismiss_required_action_callback'
		) );

		/**
		 * Set the blog / static page automatically
		 */
		add_action( 'admin_init', array( $this, 'newsmag_set_pages' ) );
	}

	/**
	 * Set the latest blog / static page automatically
	 */
	public function newsmag_set_pages() {
		if ( ! empty( $_GET ) ) {
			/**
			 * Check action
			 */
			if ( ! empty( $_GET['action'] ) && $_GET['action'] === 'set_page_automatic' ) {
				$active_tab = $_GET['tab'];
				$about      = get_page_by_title( 'Homepage' );
				update_option( 'page_on_front', $about->ID );
				update_option( 'show_on_front', 'page' );

				// Set the blog page
				$blog = get_page_by_title( 'Blog' );
				update_option( 'page_for_posts', $blog->ID );

				wp_redirect( self_admin_url( 'themes.php?page=newsmag-welcome&tab=' . $active_tab ) );
			}
		}
	}

	/**
	 * Creates the dashboard page
	 *
	 * @see   add_theme_page()
	 * @since 1.8.2.4
	 */
	public function newsmag_welcome_register_menu() {
		$action_count = $this->count_actions();
		$title        = $action_count > 0 ? __( 'About AC Rowing', 'ac_rowing' ) . '<span class="badge-action-count">' . esc_html( $action_count ) . '</span>' : __( 'About AC Rowing', 'newsmag' );

		add_theme_page( __( 'About AC Rowing', 'ac_rowing' ), $title, 'edit_theme_options', 'newsmag-welcome', array(
			$this,
			'newsmag_welcome_screen'
		) );
	}
	
	
	/**
	 * Creates slideshow post
	 *
	 * @since 1.8.2.4
	 */
/*public function create_post_slideshow() {
	  register_post_type( 'slideshow',
		array(
			'labels' => array(           
			   'name' => __( 'Slideshow' ),
			   'singular_name' => __( 'Slideshow' ),
                'add_new' => _x('Add New Slide', 'ac_rowing'),
                'add_new_item' => 'Add New Slide'  
			),
		'public' => true,
         'menu_position' => 5,
         'rewrite' => array('slug' => 'slideshow'),
         'menu_icon' => 'dashicons-video-alt',   // or 'menu_icon'=>get_template_directory_uri().'/img/invoices.png',
		 'has_archive' => true,     //Enables post type archives
         'hierarchical' => false ,    // true: deal as page -- false : deal as post
         'can_export' => true,
         'supports' => array ('title','editor','author','thumbnail','excerpt','trackbacks','custom-fields', 'comments','revisions','page-attributes','post-formats'),
         'taxonomies' => array('category','post_tag')    // An array of registered taxonomies 
                                  
		)
	);
}*/

public function add_box() {
    
    add_meta_box('box_id', 'Slideshow Image', array( $this,'content_box'), 'post', 'advanced', 'high');

}

public function content_box($post) {
	global $post;
	$slide  = esc_html (get_post_meta($post->ID, 'slideshow', true));
	///echo "<h3>Slideshow Image</h3>";
	    echo '<p class="meta-options">
             <label for="slide">'.__('Slide Image').'</label><br />
             <input id="slide" type="text" size="70" name="slide" value="'.$slide.'" />
     <input id="slide_button" type="button"  size="40" class="upload_button button" value="'.__('Upload Slider Image').'" />
      </p>';
}

public function save_postdata($post_id) {
    global $post;
    if (defined('DOING_AUTOSAVE') && DOING_AUTOSAVE) {
        return $post_id;
    }
	
// Check permissions   
    if(isset($_POST['post_type'])){       
            if (/*'page' == $_POST['post_type'] or */'post' == $_POST['post_type'] ) {
             if (!current_user_can('edit_page', $post_id))
                    return;
            }
            else {
                if (!current_user_can('edit_post', $post_id))
                    return;
            }
     }
	 
	   if(isset($_POST['slide'])){        
            update_post_meta($post->ID, 'slideshow',$_POST['slide'] );
       }
	 
}

public function my_show_extra_profile_fields( $user ) {  ?>
    <h3><?php _e('Extra Information For Rowing Race','ac-rowing');?></h3>
 
    <table class="form-table">
 
        <tr>
            <th><label for="mname"><?php _e('Middle Name','ac-rowing');?></label></th>
            <td>
   <input type="text" name="mname" id="mname" value="<?php echo esc_attr( get_the_author_meta( 'Middle Name', $user->ID ) ); ?>" class="regular-text" />
            </td>
        </tr>
       
        <tr>
            <th><label for="mobile"><?php _e('Mobile','ac-rowing');?></label></th>
            <td>
<input type="text" name="mobile" id="mobile" value="<?php echo esc_attr( get_the_author_meta( 'Mobile', $user->ID ) ); ?>" class="regular-text" />
            </td>
        </tr>
        
        <tr>
            <th><label for="gender"><?php _e('Gender : ','ac-rowing');?></label></th>
            <td>
                     <label>
                        <input type="radio" name="gender" id="male" value="male" <?php if (get_the_author_meta( 'Gender', $user->ID ) == 'male') { ?> checked <?php } ?> >
                           <?php _e('Male ','ac-rowing');?>
                      </label>
                      <label>
                        <input type="radio" name="gender" id="female" value="female" <?php if (get_the_author_meta( 'Gender', $user->ID ) == 'female') { ?> checked <?php } ?>>
                           <?php _e(' Female','ac-rowing');?>
                       </label>
            </td>
        </tr>
        
        <tr>
            <th><label for="age"><?php _e('Age','ac-rowing');?></label></th>
            <td>
                      <select id="age" name="age" class="form-control" style="width:200px;">
             <optgroup label="<?php _e('Men','ac-rowing');?>" >
                    <option value="-16M" 
		<?php if (get_the_author_meta( 'Age', $user->ID ) == '-16M') { ?> selected <?php } ?>><?php _e('Under 16','ac-rowing');?>                    </option>
                        <option value="-20M" 
           <?php if (get_the_author_meta( 'Age', $user->ID ) == '-20M') { ?> selected <?php } ?>><?php _e('Under 20','ac-rowing');?>                    </option>
                        <option value="-30M" 
              <?php if (get_the_author_meta( 'Age', $user->ID ) == '-30M') { ?> selected <?php } ?>><?php _e('Under 30','ac-rowing');?>                   </option>
                        <option value="-40M" 
                   <?php if (get_the_author_meta( 'Age', $user->ID ) == '-40M') { ?> selected <?php } ?>><?php _e('Under 40','ac-rowing');?>                   </option>
                        <option value="+50M" 
                <?php if (get_the_author_meta( 'Age', $user->ID ) == '+50M') { ?> selected <?php } ?>><?php _e('Above 50','ac-rowing')?>                       </option>
                </optgroup>
                 <optgroup label="<?php _e('Women','ac-rowing');?>" >
                    <option value="-16W" 
		<?php if (get_the_author_meta( 'Age', $user->ID ) == '-16W') { ?> selected <?php } ?>><?php _e('Under 16','ac-rowing');?>                    </option>
                        <option value="-20W" 
           <?php if (get_the_author_meta( 'Age', $user->ID ) == '-20W') { ?> selected <?php } ?>><?php _e('Under 20','ac-rowing');?>                    </option>
                        <option value="-35W" 
              <?php if (get_the_author_meta( 'Age', $user->ID ) == '-30W') { ?> selected <?php } ?>><?php _e('Under 35','ac-rowing');?>                   </option>
                        <option value="+35W" 
                <?php if (get_the_author_meta( 'Age', $user->ID ) == '+50W') { ?> selected <?php } ?>><?php _e('Above 35','ac-rowing')?>                       </option>
                </optgroup>
                      </select>
            </td>
        </tr>
        
        <tr>
            <th><label for="raceT"><?php _e('Race Type','ac-rowing');?></label></th>
            <td>
                 <select id="raceT" name="raceT" class="form-control" style="width:200px;">
     <?php
	    $races = get_terms( 'category', array(
			'orderby'    => 'name',
			'hide_empty' => 0,
			'parent' => 0,
			'description__like' => 'rowing'
        ));  
		foreach($races as $race) :
	?>  
                    <option value="<?php echo $race->term_id ;?>" 
		<?php if (get_the_author_meta( 'Race', $user->ID ) == $race->term_id) { ?> selected <?php } ?>><?php echo $race->name ;?>                    </option>
         <?php endforeach; ?>
               </select>
            </td>
        </tr>
         <tr>
            <th><label for="AddList"><?php _e('Newsletter : ','ac-rowing');?></label></th>
            <td>
                 <label >
  <input id="AddList" name="AddList" type="checkbox" <?php if (get_the_author_meta( 'Newsletter', $user->ID ) == 'on') { ?> checked <?php } ?>>
                 <?php _e('Receive A newsletter','ac-rowing');?>
                   </label>
            </td>
        </tr>
 
    </table>
    <?php
}


public function my_save_extra_profile_fields( $user_id ) {
 
    if ( !current_user_can( 'edit_user', $user_id ) )
        return false;
		
		         $mname = $_REQUEST['mname'];
		         $mobile = $_REQUEST['mobile'];	    
		         $gender = $_REQUEST['gender'];
			  
		   if(isset($_REQUEST['AddList'])) :
			    $news = $_REQUEST['AddList'];
			  else:
			     $news = "off";
			  endif;
			  
			  $age = $_REQUEST['age'];
	
	update_user_meta( absint( $user_id ), 'Middle Name', wp_kses_post( $mname) );	
    update_user_meta( absint( $user_id ), 'Mobile', wp_kses_post( $mobile) );
	update_user_meta( absint( $user_id ), 'Gender', wp_kses_post( $gender) );
	update_user_meta( absint( $user_id ), 'Age', wp_kses_post( $age) );
	update_user_meta( absint( $user_id ), 'Newsletter', wp_kses_post( $news ) );
}
	

	/**
	 * Adds an admin notice upon successful activation.
	 *
	 */
	public function newsmag_activation_admin_notice() {
		global $pagenow;

		if ( is_admin() && ( 'themes.php' == $pagenow ) && isset( $_GET['activated'] ) ) {
			add_action( 'admin_notices', array( $this, 'newsmag_welcome_admin_notice' ), 99 );
		}
	}

	/**
	 * Display an admin notice linking to the welcome screen
	 *
	 */
	public function newsmag_welcome_admin_notice() {
		?>
		<div class="updated notice is-dismissible">
			<p><?php echo sprintf( esc_html__( 'Welcome! Thank you for choosing AC Rowing! To fully take advantage of the best our theme can offer please make sure you visit our %swelcome page%s.', 'ac_rowing' ), '<a href="' . esc_url( admin_url( 'themes.php?page=newsmag-welcome' ) ) . '">', '</a>' ); ?></p>
			<p><a href="<?php echo esc_url( admin_url( 'themes.php?page=newsmag-welcome' ) ); ?>" class="button"
			      style="text-decoration: none;"><?php _e( 'Get started with AC Rowing', 'ac_rowing' ); ?></a></p>
		</div>
		<?php
	}

	/**
	 * Load welcome screen css and javascript
	 *
	 */
	public function newsmag_welcome_style_and_scripts( $hook_suffix ) {

		wp_enqueue_style( 'newsmag-welcome-screen', get_template_directory_uri() . '/inc/libraries/welcome-screen/assets/css/welcome.css' );
		wp_enqueue_script( 'newsmag-welcome-screen', get_template_directory_uri() . '/inc/libraries/welcome-screen/assets/js/welcome.js', array( 'jquery' ), '12123' );

		wp_localize_script( 'newsmag-welcome-screen', 'newsmagWelcomeScreenObject', array(
			'nr_actions_required'      => absint( $this->count_actions() ),
			'ajaxurl'                  => esc_url( admin_url( 'admin-ajax.php' ) ),
			'template_directory'       => esc_url( get_template_directory_uri() ),
			'no_required_actions_text' => __( 'Hooray! There are no required actions for you right now.', 'newsmag' )
		) );

	}

	/**
	 * Load scripts for customizer page
	 *
	 */
	public function newsmag_welcome_scripts_for_customizer() {

		wp_enqueue_style( 'newsmag-welcome-screen-customizer', get_template_directory_uri() . '/inc/libraries/welcome-screen/assets/css/welcome_customizer.css' );
		wp_enqueue_script( 'newsmag-welcome-screen-customizer', get_template_directory_uri() . '/inc/libraries/welcome-screen/assets/js/welcome_customizer.js', array( 'jquery' ), '20120206', true );

		wp_localize_script( 'newsmag-welcome-screen-customizer', 'newsmagWelcomeScreenCustomizerObject', array(
			'nr_actions_required' => absint( $this->count_actions() ),
			'aboutpage'           => esc_url( admin_url( 'themes.php?page=newsmag-welcome&tab=recommended_actions' ) ),
			'customizerpage'      => esc_url( admin_url( 'customize.php#recommended_actions' ) ),
			'themeinfo'           => __( 'View Theme Info', 'ac_rowing' ),
		) );
	}

	/**
	 * Dismiss required actions
	 *
	 * @since 1.8.2.4
	 */
	public function newsmag_dismiss_required_action_callback() {

		global $newsmag_required_actions;

		$action_id = ( isset( $_GET['id'] ) ) ? $_GET['id'] : 0;

		echo $action_id; /* this is needed and it's the id of the dismissable required action */

		if ( ! empty( $action_id ) ):

			/* if the option exists, update the record for the specified id */
			if ( get_option( 'newsmag_show_required_actions' ) ):

				$newsmag_show_required_actions = get_option( 'newsmag_show_required_actions' );

				switch ( $_GET['todo'] ) {
					case 'add';
						$newsmag_show_required_actions[ $action_id ] = true;
						break;
					case 'dismiss';
						$newsmag_show_required_actions[ $action_id ] = false;
						break;
				}

				update_option( 'newsmag_show_required_actions', $newsmag_show_required_actions );

			/* create the new option,with false for the specified id */
			else:

				$newsmag_show_required_actions_new = array();

				if ( ! empty( $newsmag_required_actions ) ):

					foreach ( $newsmag_required_actions as $newsmag_required_action ):

						if ( $newsmag_required_action['id'] == $action_id ):
							$newsmag_show_required_actions_new[ $newsmag_required_action['id'] ] = false;
						else:
							$newsmag_show_required_actions_new[ $newsmag_required_action['id'] ] = true;
						endif;

					endforeach;

					update_option( 'newsmag_show_required_actions', $newsmag_show_required_actions_new );

				endif;

			endif;

		endif;

		die(); // this is required to return a proper result
	}


	/**
	 *
	 */
	public function count_actions() {
		global $newsmag_required_actions;

		$newsmag_show_required_actions = get_option( 'newsmag_show_required_actions' );
		if ( ! $newsmag_show_required_actions ) {
			$newsmag_show_required_actions = array();
		}

		$i = 0;
		foreach ( $newsmag_required_actions as $action ) {
			$true      = false;
			$dismissed = false;

			if ( ! $action['check'] ) {
				$true = true;
			}

			if ( ! empty( $newsmag_show_required_actions ) && isset( $newsmag_show_required_actions[ $action['id'] ] ) && ! $newsmag_show_required_actions[ $action['id'] ] ) {
				$true = false;
			}

			if ( $true ) {
				$i ++;
			}
		}


		return $i;
	}


	/**
	 * @param $slug
	 *
	 * @return array|mixed|object|WP_Error
	 */
	public function call_plugin_api( $slug ) {
		include_once( ABSPATH . 'wp-admin/includes/plugin-install.php' );

		if ( false === ( $call_api = get_transient( 'newsmag_plugin_information_transient_' . $slug ) ) ) {
			$call_api = plugins_api( 'plugin_information', array(
				'slug'   => $slug,
				'fields' => array(
					'downloaded'        => false,
					'rating'            => false,
					'description'       => false,
					'short_description' => true,
					'donate_link'       => false,
					'tags'              => false,
					'sections'          => true,
					'homepage'          => true,
					'added'             => false,
					'last_updated'      => false,
					'compatibility'     => false,
					'tested'            => false,
					'requires'          => false,
					'downloadlink'      => false,
					'icons'             => true
				)
			) );
			set_transient( 'newsmag_plugin_information_transient_' . $slug, $call_api, 30 * MINUTE_IN_SECONDS );
		}

		return $call_api;
	}

	/**
	 * @param $slug
	 *
	 * @return array
	 */
	public function check_active( $slug ) {
		if ( file_exists( ABSPATH . 'wp-content/plugins/' . $slug . '/' . $slug . '.php' ) ) {
			include_once( ABSPATH . 'wp-admin/includes/plugin.php' );

			$needs = is_plugin_active( $slug . '/' . $slug . '.php' ) ? 'deactivate' : 'activate';

			return array( 'status' => is_plugin_active( $slug . '/' . $slug . '.php' ), 'needs' => $needs );
		}

		return array( 'status' => false, 'needs' => 'install' );
	}

	/**
	 * @param $arr
	 *
	 * @return mixed
	 */
	public function check_for_icon( $arr ) {
		if ( ! empty( $arr['svg'] ) ) {
			$plugin_icon_url = $arr['svg'];
		} elseif ( ! empty( $arr['2x'] ) ) {
			$plugin_icon_url = $arr['2x'];
		} elseif ( ! empty( $arr['1x'] ) ) {
			$plugin_icon_url = $arr['1x'];
		} else {
			$plugin_icon_url = $arr['default'];
		}

		return $plugin_icon_url;
	}

	/**
	 * @param $state
	 * @param $slug
	 *
	 * @return string
	 */
	public function create_action_link( $state, $slug ) {
		switch ( $state ) {
			case 'install':
				return wp_nonce_url(
					add_query_arg(
						array(
							'action' => 'install-plugin',
							'plugin' => $slug
						),
						network_admin_url( 'update.php' )
					),
					'install-plugin_' . $slug
				);
				break;
			case 'deactivate':
				return add_query_arg( array(
					                      'action'        => 'deactivate',
					                      'plugin'        => rawurlencode( $slug . '/' . $slug . '.php' ),
					                      'plugin_status' => 'all',
					                      'paged'         => '1',
					                      '_wpnonce'      => wp_create_nonce( 'deactivate-plugin_' . $slug . '/' . $slug . '.php' ),
				                      ), network_admin_url( 'plugins.php' ) );
				break;
			case 'activate':
				return add_query_arg( array(
					                      'action'        => 'activate',
					                      'plugin'        => rawurlencode( $slug . '/' . $slug . '.php' ),
					                      'plugin_status' => 'all',
					                      'paged'         => '1',
					                      '_wpnonce'      => wp_create_nonce( 'activate-plugin_' . $slug . '/' . $slug . '.php' ),
				                      ), network_admin_url( 'plugins.php' ) );
				break;
		}
	}

	/**
	 * Welcome screen content
	 *
	 * @since 1.8.2.4
	 */
	public function newsmag_welcome_screen() {
		require_once( ABSPATH . 'wp-load.php' );
		require_once( ABSPATH . 'wp-admin/admin.php' );
		require_once( ABSPATH . 'wp-admin/admin-header.php' );

		$newsmag      = wp_get_theme();
		$active_tab   = isset( $_GET['tab'] ) ? $_GET['tab'] : 'getting_started';
		$action_count = $this->count_actions();

		?>

		<div class="wrap about-wrap epsilon-wrap">

			<h1><?php echo __( 'Welcome to AC Rowing! - Version ', 'ac_rowing' ) . esc_html( $newsmag['Version'] ); ?></h1>

			<div
				class="about-text"><?php echo esc_html__( 'AC Rowing is now installed and ready to use! Get ready to build something beautiful. We hope you enjoy it! We want to make sure you have the best experience using Newsmag and that is why we gathered here all the necessary information for you. We hope you will enjoy using Newsmag, as much as we enjoy creating great products.', 'newsmag' ); ?></div>

			<div class="wp-badge epsilon-welcome-logo"></div>


			<h2 class="nav-tab-wrapper wp-clearfix">
				<a href="<?php echo esc_url( admin_url( 'themes.php?page=newsmag-welcome&tab=getting_started' ) ); ?>"
				   class="nav-tab <?php echo $active_tab == 'getting_started' ? 'nav-tab-active' : ''; ?>"><?php echo esc_html__( 'Getting Started', 'newsmag' ); ?></a>
                <a href="<?php echo esc_url( admin_url( 'themes.php?page=newsmag-welcome&tab=recommended_actions' ) ); ?>"
				   class="nav-tab <?php echo $active_tab == 'recommended_actions' ? 'nav-tab-active' : ''; ?> "><?php echo esc_html__( 'Recommended Actions', 'newsmag' ); ?>
                    <?php echo $action_count > 0 ? '<span class="badge-action-count">' . esc_html( $action_count ) . '</span>' : '' ?></a>
                <a href="<?php echo esc_url( admin_url( 'themes.php?page=newsmag-welcome&tab=recommended_plugins' ) ); ?>"
				   class="nav-tab <?php echo $active_tab == 'recommended_plugins' ? 'nav-tab-active' : ''; ?> "><?php echo esc_html__( 'Recommended Plugins', 'newsmag' ); ?></a>
                <a href="<?php echo esc_url( admin_url( 'themes.php?page=newsmag-welcome&tab=support' ) ); ?>"
				   class="nav-tab <?php echo $active_tab == 'support' ? 'nav-tab-active' : ''; ?> "><?php echo esc_html__( 'Support', 'newsmag' ); ?></a>
                <a href="<?php echo esc_url( admin_url( 'themes.php?page=newsmag-welcome&tab=features' ) ); ?>"
                   class="nav-tab <?php echo $active_tab == 'features' ? 'nav-tab-active' : ''; ?> "><?php echo esc_html__( 'Lite vs PRO', 'newsmag' ); ?></a>
			</h2>

			<?php
			switch ( $active_tab ) {
				case 'getting_started':
					require_once get_template_directory() . '/inc/libraries/welcome-screen/sections/getting-started.php';
					break;
				case 'recommended_actions':
					require_once get_template_directory() . '/inc/libraries/welcome-screen/sections/actions-required.php';
					break;
				case 'recommended_plugins':
					require_once get_template_directory() . '/inc/libraries/welcome-screen/sections/recommended-plugins.php';
					break;
				case 'support':
					require_once get_template_directory() . '/inc/libraries/welcome-screen/sections/support.php';
					break;
				case 'features':
					require_once get_template_directory() . '/inc/libraries/welcome-screen/sections/features.php';
					break;
				default:
					require_once get_template_directory() . '/inc/admin/welcome-screen/sections/getting-started.php';
					break;
			}
			?>


		</div><!--/.wrap.about-wrap-->

		<?php
	}
}
