<?php
//in header

session_set_cookie_params((60*60),'/');
session_start();
ob_start();

if(isset($_POST['add_to_session'])){
	foreach($_POST as $key=>$value){
	   $_SESSION[$key]=$_POST[$value];
	}
}

?>

 <form id="masaref_zakah_form" action="" method="POST">							
                        <div class="row form-group">
                            <label class="feild-label">مصارف الزكاة</label>
                        </div>

                        <div class="row form-group">
                            <label class="feild-label" for="address">مكان الصرف</label>
                            <select class="text-feild" name="address" id="address">
                                <option value="">إختر</option>
                            </select>
                        </div>

                        <div class="row form-group">
                            <label class="feild-label">وصف المكان</label>
                            <textarea class="text-feild" name="address_details" id="address_details"></textarea>
                        </div>
                        <div class="alert alert-warning" style="display: none;" role="alert"></div>
                        <div class="row form-group">
                            <input type="hidden" name="add_to_session" value="add_to_session"/>
                                                        <button id="electronic_payment" class="button-default">دفع إلكتروني</button>
                            <button id="banks_accounts" class="button-default">حساباتنا البنكية</button>
                            <button id="reset" class="button-default">إلغاء</button>
                        </div>
                    </form>

<script>
    $.get ( '/admin/api/GetCities' , function ( data )
    {
        for ( var i = 0 ; i < data.length ; i++ )
        {
            $ ( '#address' ).append ( '<option value="' + data[i].CityId + '">' + data[i].CityName + '</option>' ) ;
        }
    } ) ;
    $.get ( '/admin/api/GetZakahOutlets' , function ( data )
    {
        for ( var i = 0 ; i < data.length ; i++ )
        {
            $ ( '#masaref_zakah_form>div:first' ).append ( '<div class="col-xs-12" style="text-align: right;"><input type="checkbox" name="masaref_zakah[]" id="masaref_' + data[i].ZakahOutletId + '" value="' + data[i].ZakahOutletId + '"/><label class="feild-label" style="margin:0px 10px;width: auto;" for="masaref_' + data[i].ZakahOutletId + '">' + data[i].ZakahOutletName + '</label></div>' ) ;
        }
    } ) ;
</script>