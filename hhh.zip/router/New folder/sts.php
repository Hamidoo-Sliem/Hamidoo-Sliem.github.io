<?php

// Step 1 : Generate secure hash string

$PAYONE_SECRET_KEY = "Y2FkMTdlOWZiMzJjMzY4ZGFkMzhkMWIz"; // Use Yours, Please Store Your Secret Key in safe Place(eg. database) 
$transaction_id = (int)(microtime(true)*1000); //time in milleseconds 
$parameters = array();  // fill required parameters 
$parameters['TransactionID'] = $transaction_id; //TMP: 
$parameters['MerchantID'] = "ANBRedirectM";  
$parameters['Amount'] = "2000"; 
$parameters['CurrencyISOCode'] = "840"; 
$parameters['MessageID'] = "1"; 
$parameters['Quantity'] = "1"; 
$parameters['Channel'] = "0";  //fill some optional parameters 
$parameters['Language'] = "en"; 
$parameters['ThemeID'] = "1000000001";
// if this url is configured for the merchant it's not required 
$parameters['ResponseBackURL'] = "https://MerchantSite/RedirectPaymentResponsePage";
$parameters['Version'] = "1.0"; 
//Create an Ordered String of The Parameters string with Secret Key by ksort
ksort($parameters); 
$orderedString = $PAYONE_SECRET_KEY; 
foreach($parameters as $k=>$param){
	$orderedString .= $param;
	} 
	//echo "orderdString: " .$orderedString.chr(10);         // Generate SecureHash with SHA256  
	echo $secureHash = hash('sha256', $orderedString, false);
	
// Step 2: Prepare Payment Request and Send It to Redirect PHP Page (To Send a Post Request) 
$attributesData = array(); 
$attributesData["TransactionID"] = $transaction_id; 
$attributesData["MerchantID"] = "ANBRedirectM"; 
$attributesData["Amount"] = "2000"; 
$attributesData["CurrencyISOCode"] = "840";
$attributesData["MessageID"] = "1";
$attributesData["Quantity"] = "1";
$attributesData["Channel"] = "0";
$attributesData["Language"] = "en";
$attributesData["ThemeID"] = "1000000001";  // if this url is configured for the merchant it's not required, else it is required
$attributesData["ResponseBackURL"] = "http://MerchantSite/RedirectPaymentResponsePage";
$attributesData["Version"] = "1.0";
$attributesData["RedirectURL"] = "http://SmartrouteURL/SmartRoutePaymentWEB/SRPayMsgHandler";
// set secure hash in the request
$attributesData["SecureHash"] = $secureHash;
$_SESSION['SmartRouteParams'] = $attributesData;   
//redirect to "redirect.php"; 
header('location: redirect.php'); 
exit();


// in another page

if(!session_id()){
	session_start(); 
	 } 
	  // read the paramters from session  
	  $parameters = $_SESSION['SmartRouteParams']; 
	   $redirectURL = $parameters["RedirectURL"]; 
	    $merchantID = $parameters['MerchantID']; 
		 $amount = $parameters['Amount']; 
		  $currencyCode = $parameters['CurrencyISOCode']; 
		   $language = $parameters['Language']; 
		    $messageID = $parameters['MessageID']; 
			 $transactionID = $parameters['TransactionID']; 
			  $themeID = $parameters['ThemeID']; 
			   $responseBackURL= $parameters['ResponseBackURL']; 
			    $quantity = $parameters['Quantity']; 
				 $channel = $parameters['Channel']; 
				  $secureHash = $parameters['SecureHash']; 
				   $version = $parameters['Version'];
				    
				   ?>
                   
 