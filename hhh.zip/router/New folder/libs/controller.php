<?php

class controller {
	
    protected $error;
	
	public function __construct () {
		
	}
	
	protected function render ($path ,$var =array() ) {
		include('views/index.php');
	}
	
	private function _include ($path ,$var =array() ) {
		if(count($var) != 0) {
			extract ($var);
		include('views/'. $path . '.php');
		}
	}
		
}