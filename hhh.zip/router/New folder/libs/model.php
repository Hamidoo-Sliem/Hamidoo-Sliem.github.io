<?php

class model extends PDO {
	
	private $username = "root";
	private $password = "ITG1";
	private $dbhost="localhost";
	private $dbname="zakah";
	
	public function __construct () {
		parent::__construct('mysql:host='.$this->dbhost.';dbname='.$this->dbname , $this->username , $this->password );
	}
	
}