<?php

class session {
	
	public static function init () {
	    session_set_cookie_params((60*20),'/');
        session_start();
		//session_regenerate_id(true);
	}
	
	public static function is_user_login () {
		
	   if(isset($_SESSION['login']) && isset($_SESSION['user_id']) && isset($_SESSION['user_name'])) {
		   return true ;
	   } else {
		   return false;  
	   }
		//session_regenerate_id(true);
	}
	
	public static function destroy () {
		unset($_SESSION['login']);
		unset($_SESSION['user_name']);
		unset($_SESSION['user_id']);
	}
	
}