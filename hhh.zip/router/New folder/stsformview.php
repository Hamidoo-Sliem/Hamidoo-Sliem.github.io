<?php 
 if(!session_id()) { 
 session_start(); 
 } 
  ?> 
   <!-- STEP 3: Create PHP Page send Request -->  
  <?php  // read the parameters from request 
 $paymentParameters = $_SESSION["PaymentParams"]; 
 $redirectURL = (String) $paymentParameters["RedirectURL"]; 
 $amount = (String) $paymentParameters["Amount"];
 $currencyCode = (String) $paymentParameters["CurrencyISOCode"]; 
 $transactionID = (String) $paymentParameters["TransactionID"]; 
 $merchantID = (String) $paymentParameters["MerchantID"]; 
 $language = (String) $paymentParameters["Language"]; 
 $messageID = (String) $paymentParameters["MessageID"]; 
 $secureHash = (String) $paymentParameters["SecureHash"]; 
 $themeID = (String) $paymentParameters["ThemeID"]; 
 $responseBackURL = (String) $paymentParameters["ResponseBackURL"]; 
 $channel = (String) $paymentParameters["Channel"];
 $quantity = (String) $paymentParameters["Quantity"];
 
 $version = (String) $paymentParameters["Version"]; 
 $paymentMethod = (String) $paymentParameters["PaymentMethod"]; 
 //optional for sadad 
// $sadadOlpId = (String)$paymentParameters['SadadOlpId'];
  ?>
  
  <html>
  <body> 
  <form action="<?php echo $redirectURL?>" method="post" name="redirectForm"> 
   <input name="MerchantID" type="hidden" value="<?php echo $merchantID?>"/> 
  <input name="Amount" type="hidden" value="<?php echo $amount?>"/> 
  <input name="CurrencyISOCode" type="hidden" value="<?php echo $currencyCode?>"/>
  <input name="Language" type="hidden" value="<?php echo $language?>"/> 
  <input name="MessageID" type="hidden" value="<?php echo $messageID?>"/>
  <input name="TransactionID" type="hidden" value="<?php echo $transactionID?>"/> 
  <input name="ThemeID" type="hidden" value="<?php echo $themeID?>"/> 
  <input name="ResponseBackURL" type="hidden" value="<?php echo $responseBackURL?>"/> 
  <input name="Quantity" type="hidden" value="<?php echo $quantity?>"/> 
  <input name="Channel" type="hidden" value="<?php echo $channel?>"/>
  <input name="Version" type="hidden" value="<?php echo $version?>"/> 
   <input name="PaymentMethod" type="hidden" value="<?php echo $paymentMethod?>"/> 
   <!--input name="SadadOlpId" type="hidden" value="<?php #echo $sadadOlpId ?>"-->
   <label>Card Number</label>
   <input name="CardNumber" type="text" value=""/> <br/> 
   <label>Card Holder Name</label>
   <input name="CardHolderName" type="text" value=""/><br/> 
   <label>Security Code</label> 
   <input name="SecurityCode" type="text" value=""/><br/>
    <label>Year Expiry Date</label> 
    <input name="ExpiryDateYear" type="text" value=""/><br/> 
    <label>Month Expiry Date</label>
     <input name="ExpiryDateMonth" type="text" value=""/>  <br/> 
      <input name="SecureHash" type="hidden" value="<?php echo $secureHash ?>"/>
      <input type="submit" value="Proceed" />
      </form>
       </body>
   </html>

 