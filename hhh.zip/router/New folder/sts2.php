<?php 
 if(!session_id()) { 
 session_start(); 
 } 
  ?>
<?php
// Use Yours, Please Store Your Secret Key in safe Place(eg. database) 
$SECRET_KEY = "Y2FkMTdlOWZiMzJjMzY4ZGFkMzhkMWIz"; 

 // get All Request Parameters
 $parameterNames = isset($_REQUEST) ? array_keys($_REQUEST) :array()  ;
  // store all response Parameters to generate Response Secure Hash 
  // and get Parameters to use it later in your Code
 $responseParameters = array() ;
 foreach($parameterNames as $paramName){ 
 $responseParameters[$paramName] = filter_input(INPUT_POST,$paramName);
  } 
  //order parameters by key using ksort 
 ksort($responseParameters);
 $orderedString = $SECRET_KEY;
 foreach($responseParameters as $k=>$param){ 
 $orderedString .= $param;
  } 
 echo "--- Ordered String ---".chr(10); 
 echo $orderedString.chr(10); 
  // Generate SecureHash with SHA256 25. 
 $secureHash = hash('sha256', $orderedString, false); 
  // get the received secure hash from result map 
  $receivedSecureHash = filter_input(INPUT_POST,'Response.SecureHash'); 
  // Now that we have the map, order it to generate secure hash and compare it with the received one
   if($receivedSecureHash !== $secureHash) { 
    // IF they are not equal then the response shall not be accepted 
	echo "Received Secure Hash does not Equal generated Secure hash";
        }else{ 
	 // Complete the Action get other parameters from result map and do 
	 // your processes 37. // Please refer to The Integration Manual to see the List of The
	  // Received Parameters  
  echo "Status is: ".filter_input(INPUT_POST,'Response.Status');
   }
   
   
   
   // Step 2: Prepare Payment Request and Send It to Redirect Page (To Send a Post Request)
  $paymentParameters = array(); 
  $paymentParameters["TransactionID"] = $transactionId; 
  $paymentParameters["MerchantID"] = "ANBRedirectM"; 
  $paymentParameters["Amount"] = "2000"; 
  $paymentParameters["CurrencyISOCode"] = "840"; 
  $paymentParameters["MessageID"] = "1"; 
  $paymentParameters["Quantity"] = "1";
  $paymentParameters["Channel"] = "0";
  $paymentParameters["PaymentMethod"] = "1";
   //$paymentParameters["SadadOlpId"] = "testSadad"; 
  $paymentParameters["Language"] = "en";
  $paymentParameters["ThemeID"] = "1000000001";
  $paymentParameters["ResponseBackURL"] ="https://MerchantSite/RedirectPaymentResponsePage";
  // if this url is configured for the merchant it's not required 
  $paymentParameters["Version"] = "1.0"; 
  $paymentParameters["RedirectURL"] = "http://localhost:9080/SmartRoutePaymentWEB/SRPayMsgHandler"; 
   // set secure hash in the requrest 
   $paymentParameters["SecureHash"] = $secureHash;
   $_SESSION['PaymentParams'] = $paymentParameters;
   
 header('location: stsformview.php');
 