<?php

class credit_payment_model extends model{
	
   	public function __construct () {
		parent::__construct();
	}
	
	public function get_all() {
	    	$cpm = $this->prepare("SELECT * FROM city");
			$cpm->execute();
			return $cpm->fetchAll(PDO::FETCH_ASSOC) ;
	}
	
	public function insert($data) {
	              	
	}
	
}