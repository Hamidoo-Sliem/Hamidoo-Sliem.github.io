/**
 Home page 
 */
$ ( document ).ready ( function ()
{

    $ ( '#chack_all' ).change ( function ()
    {
        if ( $ ( this ).is ( ':checked' ) )
        {
            $ ( 'input[name="report_id[]"' ).attr ( 'checked' , 'checked' ) ;
            $ ( 'input[name="report_id[]"' ).prop ( 'checked' , true ) ;
        }
        else
        {
            $ ( 'input[name="report_id[]"' ).removeAttr ( 'checked' ) ;
            $ ( 'input[name="report_id[]"' ).prop ( 'checked' , false ) ;
        }
    } ) ;

    $ ( document ).on ( "scroll" , onScroll ) ;

    //smoothscroll
    $ ( 'a[href^="/#"]' ).on ( 'click' , function ( e )
    {
        e.preventDefault () ;
        $ ( document ).off ( "scroll" ) ;

        $ ( 'a' ).each ( function ()
        {
            $ ( this ).removeClass ( 'active' ) ;
        } )
        $ ( this ).addClass ( 'active' ) ;

        console.log ( this.hash ) ;

        var target = this.hash ,
                menu = target ;
        if ( $ ( target ).length == 0 )
        {
            window.location.href = "/" + target ;
        }
        //console.log($(target).length);
        $target = $ ( target ) ;

        $ ( 'html, body' ).stop ().animate ( {
            'scrollTop' : $target.offset ().top - 10
        } , 500 , 'swing' , function ()
        {
            //window.location.hash = target ;
            $ ( document ).on ( "scroll" , onScroll ) ;
        } ) ;
    } ) ;




    setInterval ( function ()
    {
        var d = new Date () ;
        var month = d.getMonth () + 1 ;
        var day = d.getDate () ;
        var h = d.getHours () ;
        var m = d.getMinutes () ;
        if ( h > 12 )
        {
            var sun = "مساءً" ;
            h = h - 12
        }
        else
        {
            var sun = "صباحاً" ;
        }
        var output = ( h < 10 ? '0' : '' ) + h + ":" + ( m < 10 ? '0' : '' ) + m + " " + d.getFullYear () + '/' +
                ( month < 10 ? '0' : '' ) + '' + month + '/' +
                ( day < 10 ? '0' : '' ) + '' + day + " " + sun ;
        $ ( '#date' ).text ( output ) ;

    } , 1000 ) ;

} ) ;

function add_more_accounts ()
{
    var html = "" ;
    html += '<div class="accounts_by_bank">' ;
    html += '<div class="col-sm-6">' ;
    html += '<label class="feild-label">إسم الحساب</label>' ;
    html += '<input type="text" value="" name="bank_name[]" id="" class="text-feild">' ;
    html += '</div> ' ;
    html += '<div class="col-sm-6">' ;
    html += '<label class="feild-label">رقم الحساب</label>' ;
    html += '<input type="text" value="" name="account_number[]" id="" class="text-feild">' ;
    html += '</div>' ;
    html += '</div>' ;
    jQuery ( '#more_accounts' ).append ( html ) ;

}


function onScroll ( event )
{
    var scrollPos = $ ( document ).scrollTop () ;
    $ ( '#menu-center a' ).each ( function ()
    {
        var currLink = $ ( this ) ;
        var refElement = $ ( currLink.attr ( "href" ).replace ( '/' , '' ) ) ;
        if ( refElement.length != 0 )
        {
            if ( refElement.position ().top <= scrollPos && refElement.position ().top + refElement.height () > scrollPos )
            {
                $ ( '#menu-center ul li a' ).removeClass ( "active" ) ;
                currLink.addClass ( "active" ) ;
            }
            else
            {
                currLink.removeClass ( "active" ) ;
            }
        }
    } ) ;
}

/**
 End Home page
 */
/**
 Money zakah
 */
$ ( document ).ready ( function ()
{
    if ( $ ( '#money_zakah_form' ).length == 0 )
        return false ;

    function get_amount ()
    {
        $.post ( 'admin/api/get_options' , function ( data )
        {
            data = JSON.parse ( data ) ;
            if ( data.error != 0 )
            {
                alert ( data.message ) ;
            }
            else
            {
                $ ( '#gold_24' ).val ( data.message.gold_24 ) ;
                $ ( '#quorum' ).val ( parseFloat ( data.message.gold_24 * 85 ).toFixed ( 3 ) ) ;
            }
        } ) ;
    }
    $ ( '#reset' ).on ( 'click' , function ()
    {
        reset () ;
    } ) ;

    function reset ()
    {
        get_amount () ;
        hide_alert () ;
        $ ( '#money_zakah_form' ).attr ( 'action' , '' ) ;
    }
    $ ( '#money,#money_year' ).keyup ( function ()
    {
        calculation () ;
    } ) ;
    function hide_alert ()
    {
        setTimeout ( function ()
        {
            $ ( '.alert-warning' ).slideUp ( 400 ) ;
            $ ( '.alert-warning' ).removeClass ( 'alert-danger' ) ;
        } , 10000 ) ;
    }

    function calculation ()
    {
        $ ( '#money_zakah' ).val ( 0 ) ;
        $ ( '#money_zakah_form' ).attr ( 'action' , '' ) ;
        //reset();
        $ ( '.alert-warning' ).hide () ;
        $ ( '.alert-warning' ).removeClass ( 'alert-danger' ) ;
        if ( $ ( '#money' ).val ().length == 0 )
        {
            $ ( '.alert-warning' ).addClass ( 'alert-danger' ) ;
            $ ( '.alert-warning' ).html ( 'الرجاء إدخال مقدار المال' ) ;
            //$ ( '.alert-warning' ).slideDown ( 400 ) ;
            //hide_alert () ;
            return false ;
        }
        var money = parseFloat ( $ ( '#money' ).val () ) ;
        var zakah = parseFloat ( $ ( '#quorum' ).val () ) ;
        if ( money < zakah )
        {
            $ ( '.alert-warning' ).removeClass ( 'alert-danger' ) ;
            $ ( '.alert-warning' ).html ( 'لا زكاة فيه لعدم إكتمال النصاب' ) ;
            //$ ( '.alert-warning' ).slideDown ( 400 ) ;
            //$ ( '#money_zakah' ).val ( 0 ) ;
            //hide_alert () ;
            return false ;
        }
        var all_money = money ;
        var all_zakah = 0 ;
        for ( var i = 0 ; i < parseInt ( $ ( '#money_year' ).val () ) ; i++ )
        {
            if ( all_money >= zakah )
            {
                var z = ( ( all_money * 2.5 ) / 100 ) ;
                all_money = all_money - z ;
                all_zakah += z ;
            }
        }
        $ ( '#money_zakah' ).val ( all_zakah.toFixed ( 3 ) ) ;
        return true ;
    }

    $ ( '#continue' ).on ( 'click' , function ()
    {
        if ( calculation () )
        {
            $ ( '#money_zakah_form' ).attr ( 'action' , '/masaref_zakah.php' ) ;
            $ ( '#money_zakah_form' ).submit () ;
        }
        else
        {
            $ ( '.alert-warning' ).slideDown ( 400 ) ;
            hide_alert () ;
        }
    } ) ;
    $ ( '#add_gold' ).on ( 'click' , function ()
    {
        if ( calculation () )
        {
            $ ( '#money_zakah_form' ).attr ( 'action' , '/gold_zakah.php' ) ;
            $ ( '#money_zakah_form' ).submit () ;
        }
        else
        {
            $ ( '.alert-warning' ).slideDown ( 400 ) ;
            hide_alert () ;
            $ ( '#money_zakah' ).val ( 0 ) ;
        }
    } ) ;
    $ ( '#money,#money_year' ).keydown ( function ( e )
    {
        // Allow: backspace, delete, tab, escape, enter and .
        if ( $.inArray ( e.keyCode , [ 46 , 8 , 9 , 27 , 13 , 110 , 190 ] ) !== -1 ||
                // Allow: Ctrl+A, Command+A
                        ( e.keyCode === 65 && ( e.ctrlKey === true || e.metaKey === true ) ) ||
                        // Allow: home, end, left, right, down, up
                                ( e.keyCode >= 35 && e.keyCode <= 40 ) )
                {
                    // let it happen, don't do anything
                    return ;
                }
                // Ensure that it is a number and stop the keypress
                if ( ( e.shiftKey || ( e.keyCode < 48 || e.keyCode > 57 ) ) && ( e.keyCode < 96 || e.keyCode > 105 ) )
                {
                    e.preventDefault () ;
                }
            } ) ;

    get_amount () ;
} ) ;
/**
 End Money zakah
 */
/**
 money_alsadaqat
 */
$ ( document ).ready ( function ()
{

    if ( $ ( '#money_alsadaqat_form' ).length == 0 )
        return false ;

    function hide_alert ()
    {
        setTimeout ( function ()
        {
            $ ( '.alert-warning' ).slideUp ( 400 ) ;
            $ ( '.alert-warning' ).removeClass ( 'alert-danger' ) ;
        } , 10000 ) ;
    }

    function calculation ()
    {
        $ ( '#money_alsadaqat_form' ).attr ( 'action' , '' ) ;
        //reset();
        $ ( '.alert-warning' ).hide () ;
        $ ( '.alert-warning' ).removeClass ( 'alert-danger' ) ;
        if ( $ ( '#money_alsadaqat' ).val ().length == 0 )
        {
            $ ( '.alert-warning' ).addClass ( 'alert-danger' ) ;
            $ ( '.alert-warning' ).html ( 'الرجاء إدخال مقدار المال' ) ;
            //$ ( '.alert-warning' ).slideDown ( 400 ) ;
            //hide_alert () ;
            return false ;
        }
        $ ( '#money_alsadaqat' ).val ( parseFloat ( $ ( '#money_alsadaqat' ).val () ).toFixed ( 3 ) ) ;
        return true ;
    }

    $ ( '#continue' ).on ( 'click' , function ()
    {
        if ( calculation () )
        {
            $ ( '#money_alsadaqat_form' ).attr ( 'action' , '/masaref_zakah.php' ) ;
            $ ( '#money_alsadaqat_form' ).submit () ;
        }
        else
        {
            $ ( '.alert-warning' ).slideDown ( 400 ) ;
            hide_alert () ;
        }
    } ) ;

    $ ( '#money_alsadaqat' ).keydown ( function ( e )
    {
        // Allow: backspace, delete, tab, escape, enter and .
        if ( $.inArray ( e.keyCode , [ 46 , 8 , 9 , 27 , 13 , 110 , 190 ] ) !== -1 ||
                // Allow: Ctrl+A, Command+A
                        ( e.keyCode === 65 && ( e.ctrlKey === true || e.metaKey === true ) ) ||
                        // Allow: home, end, left, right, down, up
                                ( e.keyCode >= 35 && e.keyCode <= 40 ) )
                {
                    // let it happen, don't do anything
                    return ;
                }
                // Ensure that it is a number and stop the keypress
                if ( ( e.shiftKey || ( e.keyCode < 48 || e.keyCode > 57 ) ) && ( e.keyCode < 96 || e.keyCode > 105 ) )
                {
                    e.preventDefault () ;
                }
            } ) ;

} ) ;
/**
 End money_alsadaqat
 */
/*
 * Massaref Zakah
 */
$ ( document ).ready ( function ()
{
    if ( $ ( '#masaref_zakah_form' ).length == 0 )
    {
        return false ;
    }

    $ ( '#electronic_payment' ).on ( 'click' , function ()
    {
        $ ( '#masaref_zakah_form' ).attr ( 'action' , '/electronic_payment.php' ) ;
        $ ( '#masaref_zakah_form' ).submit () ;
    } ) ;

    $ ( '#banks_accounts' ).on ( 'click' , function ()
    {
        $ ( '#masaref_zakah_form' ).attr ( 'action' , '/banks_account.php' ) ;
        $ ( '#masaref_zakah_form' ).submit () ;
    } ) ;
    $ ( '#paypal' ).on ( 'click' , function ()
    {
        $ ( '#masaref_zakah_form' ).attr ( 'action' , '/pay_pal.php' ) ;
        $ ( '#masaref_zakah_form' ).submit () ;
    } ) ;
} ) ;
/**
 End Massaref Zakah
 */
/**
 * electronic_payment
 */

$ ( document ).ready ( function ()
{
    if ( $ ( '#electronic_payment_form' ).length == 0 )
    {
        return false ;
    }

    $.post ( 'admin/api/get_options' , function ( data )
    {
        data = JSON.parse ( data ) ;
        if ( data.error != 0 )
        {
            alert ( data.message ) ;
        }
        else
        {
            //$ ( '#efawateercom' ).val ( data.message.efawateercom ) ;
            $ ( '#total' ).val ( parseFloat ( $ ( '#total_table' ).html () ) /*+ parseFloat ( data.message.efawateercom )*/ ) ;
        }
    } ) ;

    function hide_alert ()
    {
        setTimeout ( function ()
        {
            $ ( '.alert-warning' ).slideUp ( 400 ) ;
            $ ( '.alert-warning' ).removeClass ( 'alert-danger' ) ;
        } , 10000 ) ;
    }

    $ ( '#ok' ).on ( 'click' , function ( e )
    {
        e.preventDefault () ;
        /*$ ( '.alert-warning' ).html ( 'هذه الخدمة متوقفة حالية' ) ;
         $ ( '.alert-warning' ).addClass ( 'alert-danger' ) ;
         $ ( '.alert-warning' ).slideDown ( 400 ) ;
         hide_alert () ;
         //return false ;*/
        if ( $ ( '#username' ).val ().length == 0 )
        {
            $ ( '.alert-warning' ).html ( 'الرجاء إدخال الاسم' ) ;
            $ ( '.alert-warning' ).addClass ( 'alert-danger' ) ;
            $ ( '.alert-warning' ).slideDown ( 400 ) ;
            hide_alert () ;
            return false ;
        }
        if ( $ ( '#mobile' ).val ().length == 0 )
        {
            $ ( '.alert-warning' ).html ( 'الرجاء إدخال الهاتف النقال' ) ;
            $ ( '.alert-warning' ).addClass ( 'alert-danger' ) ;
            $ ( '.alert-warning' ).slideDown ( 400 ) ;
            hide_alert () ;
            return false ;
        }
        //$ ( '#electronic_payment_form' ).attr ( 'action' , '/admin/api/get_efawateercom_id' ) ;
        $.ajax ( {
            url : '/admin/api/get_efawateercom_id' ,
            data : new FormData ( $ ( '#electronic_payment_form' )[0] ) ,
            method : 'POST' ,
            processData : false ,
            contentType : false ,
            success : function ( data )
            {
                data = JSON.parse ( data ) ;
                if ( data.error == 1 )
                {
                    $ ( '.alert-warning' ).addClass ( 'alert-success' ) ;
                    $ ( '.alert-warning' ).html ( '<h3>' + data.id + '</h3><div>إحتفظ بهذا الرقم لاستخدامه في خدمة إي فواتيركم</div>' ) ;
                    $ ( '.alert-warning' ).slideDown ( 400 ) ;
                    $ ( '#ok' ).remove () ;
                    $ ( '#cancel' ).remove () ;
                }
                else
                {
                    $ ( '.alert-warning' ).addClass ( 'alert-danger' ) ;
                    $ ( '.alert-warning' ).html ( data.message ) ;
                    $ ( '.alert-warning' ).slideDown ( 400 ) ;
                    hide_alert () ;
                }
            }
        } ) ;
        //$ ( '#electronic_payment_form' ).submit () ;
    } ) ;

    $ ( '#cancel' ).on ( 'click' , function ()
    {
        $ ( '#electronic_payment_form' ).attr ( 'action' , '/clear_zakah.php' ) ;
        $ ( '#electronic_payment_form' ).submit () ;
    } ) ;

} ) ;
/**
 * End electronic_payment_form
 */
/**
 * PayPal
 */
$ ( document ).ready ( function ()
{
    if ( $ ( '#paypal_form' ).length == 0 )
    {
        return false ;
    }

    $.post ( 'admin/api/get_currency' , function ( data )
    {
        if ( data.SuccesFlag == -1 )
        {
            alert ( data.MSG ) ;
        }
        else
        {
            $ ( '#total' ).val ( parseFloat ( parseFloat ( $ ( '#total' ).val () ) * data.Result[0].currency_exchange_rate ).toFixed ( 2 ) ) ;
            call_pay_pall_button ( $ ( '#total' ).val () ) ;
        }
    } ) ;
} ) ;
/**
 * End PayPal 
 */
/**
 * Gold Zakah
 */
$ ( document ).ready ( function ()
{
    var amounts = '' ;
    if ( $ ( '#gold_zakah_form' ).length == 0 )
    {
        return false ;
    }
    function get_amount ()
    {
        $.post ( 'admin/api/get_options' , function ( data )
        {
            data = JSON.parse ( data ) ;
            if ( data.error != 0 )
            {
                alert ( data.message ) ;
            }
            else
            {
                amounts = data.message ;
                $ ( '#gold_24' ).val ( data.message.gold_24 ) ;
                $ ( '#quorum' ).val ( parseFloat ( data.message.gold_24 * 85 ).toFixed ( 3 ) ) ;
            }
        } ) ;
    }

    $ ( '#reset' ).on ( 'click' , function ()
    {
        reset () ;
    } ) ;
    function reset ()
    {
        get_amount () ;
        hide_alert () ;
        $ ( '#gold_zakah_form' ).attr ( 'action' , '' ) ;
        $ ( '#add_money' ).hide () ;
        $ ( '#continue' ).hide () ;
    }
    $ ( '#gold,#gold_year' ).keyup ( function ()
    {
        calculation () ;
    } ) ;
    $ ( 'input[name="gold_type"]' ).on ( 'change' , function ()
    {
        calculation () ;
    } ) ;

    $ ( '#gold,#gold_year' ).keydown ( function ( e )
    {
        // Allow: backspace, delete, tab, escape, enter and .
        if ( $.inArray ( e.keyCode , [ 46 , 8 , 9 , 27 , 13 , 110 , 190 ] ) !== -1 ||
                // Allow: Ctrl+A, Command+A
                        ( e.keyCode === 65 && ( e.ctrlKey === true || e.metaKey === true ) ) ||
                        // Allow: home, end, left, right, down, up
                                ( e.keyCode >= 35 && e.keyCode <= 40 ) )
                {
                    // let it happen, don't do anything
                    return ;
                }
                // Ensure that it is a number and stop the keypress
                if ( ( e.shiftKey || ( e.keyCode < 48 || e.keyCode > 57 ) ) && ( e.keyCode < 96 || e.keyCode > 105 ) )
                {
                    e.preventDefault () ;
                }
            } ) ;

    get_amount () ;
    function hide_alert ()
    {
        setTimeout ( function ()
        {
            $ ( '.alert-warning' ).slideUp ( 400 ) ;
            $ ( '.alert-warning' ).removeClass ( 'alert-danger' ) ;
        } , 10000 ) ;
    }

    function calculation ()
    {
        //get_amount () ;
        // claculation the gold 
        $ ( '#gold_money_zakah' ).val ( 0 ) ;
        if ( $ ( '#gold' ).val ().length == 0 )
        {
            $ ( '.alert-warning' ).html ( 'الرجاء إدخال مقدار الذهب' ) ;
            $ ( '.alert-warning' ).addClass ( 'alert-danger' ) ;
            //$ ( '.alert-warning' ).slideDown ( 400 ) ;
            //hide_alert () ;
            return false ;
        }
        if ( $ ( 'input[name="gold_type"]:checked' ).length == 0 )
        {
            $ ( '.alert-warning' ).html ( 'الرجاء إختيار عيار الذهب' ) ;
            $ ( '.alert-warning' ).addClass ( 'alert-danger' ) ;
            //$ ( '.alert-warning' ).slideDown ( 400 ) ;
            //hide_alert () ;
            return false ;
        }
        // Calculatin Giram
        var gold = parseFloat ( $ ( '#gold' ).val () ) ;
        var gold_type = parseFloat ( $ ( 'input[name="gold_type"]:checked' ).val () ) ;
        var grames = parseFloat ( ( gold_type * gold ) / 24 ) ;
        if ( grames < 85 )
        {
            $ ( '.alert-warning' ).html ( 'الذهب لم يبلغ النصاب' ) ;
            $ ( '.alert-warning' ).removeClass ( 'alert-danger' ) ;
            //$ ( '.alert-warning' ).slideDown ( 400 ) ;
            //hide_alert () ;
            return false ;
        }
        $ ( '#gold_24' ).val ( amounts.gold_24 ) ;
        $ ( '#gold_money' ).val ( ( grames * amounts.gold_24 ).toFixed ( 3 ) ) ;
        //var amount = parseFloat ( ( ( grames * amounts.gold_24 ) * 2.5 ) / 100 );//.toFixed ( 3 ) ;
        var money = parseFloat ( grames * amounts.gold_24 ) ;

        var zakah = parseFloat ( amounts.gold_24 * 85 ) ;
        var all_money = money ;
        var all_zakah = 0 ;
        for ( var i = 0 ; i < parseInt ( $ ( '#gold_year' ).val () ) ; i++ )
        {
            if ( all_money >= zakah )
            {
                var z = ( ( all_money * 2.5 ) / 100 ) ;
                all_money = all_money - z ;
                all_zakah += z ;
            }
        }
        $ ( '#gold_money_zakah' ).val ( all_zakah.toFixed ( 3 ) ) ;
        //$ ( '#add_money' ).show () ;
        //$ ( '#continue' ).show () ;
        return true ;
    }

    $ ( '#add_money' ).on ( 'click' , function ()
    {
        if ( calculation () )
        {
            $ ( '#gold_zakah_form' ).attr ( 'action' , '/money_zakah.php' ) ;
            $ ( '#gold_zakah_form' ).submit () ;
        }
        else
        {
            $ ( '.alert-warning' ).slideDown ( 400 ) ;
            hide_alert () ;
            $ ( '#gold_money_zakah' ).val ( 0 ) ;
        }
    } ) ;

    $ ( '#continue' ).on ( 'click' , function ()
    {
        if ( calculation () )
        {
            $ ( '#gold_zakah_form' ).attr ( 'action' , '/masaref_zakah.php' ) ;
            $ ( '#gold_zakah_form' ).submit () ;
        }
        else
        {
            $ ( '.alert-warning' ).slideDown ( 400 ) ;
            hide_alert () ;
            $ ( '#gold_money_zakah' ).val ( 0 ) ;
        }
    } ) ;
} ) ;
/**
 * End Gold Zakah
 */
/**
 * Silver Zakah
 */
$ ( document ).ready ( function ()
{
    var amounts = '' ;
    if ( $ ( '#silver_zakah_form' ).length == 0 )
    {
        return false ;
    }
    function get_amount ()
    {
        $.post ( 'admin/api/get_options' , function ( data )
        {
            data = JSON.parse ( data ) ;
            if ( data.error != 0 )
            {
                alert ( data.message ) ;
            }
            else
            {
                amounts = data.message ;
                $ ( '#silver_grames' ).val ( data.message.silver_999 ) ;
                $ ( '#quorum' ).val ( parseFloat ( data.message.silver_999 * 595 ).toFixed ( 3 ) ) ;
            }
        } ) ;
    }
    $ ( '#reset' ).on ( 'click' , function ()
    {
        reset () ;
    } ) ;
    function reset ()
    {
        get_amount () ;
        hide_alert () ;
        $ ( '#silver_zakah_form' ).attr ( 'action' , '' ) ;
        //$ ( '#continue' ).hide () ;
    }
    $ ( '#silver,#silver_year' ).keyup ( function ()
    {
        calculation () ;
    } ) ;
    $ ( 'input[name="silver_type"]' ).on ( 'change' , function ()
    {
        calculation () ;
        //$ ( '#calc' ).click();
        //reset();
    } ) ;

    $ ( '#silver, #silver_year' ).keydown ( function ( e )
    {
        // Allow: backspace, delete, tab, escape, enter and .
        if ( $.inArray ( e.keyCode , [ 46 , 8 , 9 , 27 , 13 , 110 , 190 ] ) !== -1 ||
                // Allow: Ctrl+A, Command+A
                        ( e.keyCode === 65 && ( e.ctrlKey === true || e.metaKey === true ) ) ||
                        // Allow: home, end, left, right, down, up
                                ( e.keyCode >= 35 && e.keyCode <= 40 ) )
                {
                    // let it happen, don't do anything
                    return ;
                }
                // Ensure that it is a number and stop the keypress
                if ( ( e.shiftKey || ( e.keyCode < 48 || e.keyCode > 57 ) ) && ( e.keyCode < 96 || e.keyCode > 105 ) )
                {
                    e.preventDefault () ;
                }
            } ) ;

    get_amount () ;
    function hide_alert ()
    {
        setTimeout ( function ()
        {
            $ ( '.alert-warning' ).slideUp ( 400 ) ;
            $ ( '.alert-warning' ).removeClass ( 'alert-danger' ) ;
        } , 10000 ) ;
    }
    //$ ( '#calc' ).on ( 'click' , function ()
    function calculation ()
    {
        //get_amount () ;
        // claculation the gold 
        $ ( '#silver_money_zakah' ).val ( 0 ) ;
        if ( $ ( '#silver' ).val ().length == 0 )
        {
            $ ( '.alert-warning' ).html ( 'الرجاء إدخال مقدار الفضة' ) ;
            $ ( '.alert-warning' ).addClass ( 'alert-danger' ) ;
            //$ ( '.alert-warning' ).slideDown ( 400 ) ;
            //hide_alert () ;
            return false ;
        }
        if ( $ ( 'input[name="silver_type"]:checked' ).length == 0 )
        {
            $ ( '.alert-warning' ).html ( 'الرجاء إختيار عيار الفضة' ) ;
            $ ( '.alert-warning' ).addClass ( 'alert-danger' ) ;
            //$ ( '.alert-warning' ).slideDown ( 400 ) ;
            //hide_alert () ;
            return false ;
        }
        // Calculatin Giram
        var silver = parseFloat ( $ ( '#silver' ).val () ) ;
        var silver_type = parseFloat ( $ ( 'input[name="silver_type"]:checked' ).val () ) ;
        var grames = parseFloat ( ( silver_type * silver ) / 999 ) ;
        if ( grames < 595 )
        {
            $ ( '.alert-warning' ).html ( 'الفضة لم تبلغ النصاب' ) ;
            $ ( '.alert-warning' ).removeClass ( 'alert-danger' ) ;
            //$ ( '.alert-warning' ).slideDown ( 400 ) ;
            //hide_alert () ;
            $ ( '#silver_zakah_form' ).attr ( 'action' , '' ) ;
            //$ ( '#continue' ).hide () ;
            //$ ( '#silver_money_zakah' ).val ( 0 ) ;
            return false ;
        }
        $ ( '#silver_grames' ).val ( amounts.silver_999 ) ;
        $ ( '#silver_money' ).val ( ( grames * amounts.silver_999 ).toFixed ( 3 ) ) ;
        //var amount = parseFloat ( ( ( grames * amounts.silver_999 ) * 2.5 ) / 100 ).toFixed ( 3 ) ;
        var money = parseFloat ( grames * amounts.silver_999 ) ;
        var zakah = parseFloat ( amounts.silver_999 * 595 ) ;
        var all_money = money ;
        var all_zakah = 0 ;
        for ( var i = 0 ; i < parseInt ( $ ( '#silver_year' ).val () ) ; i++ )
        {
            if ( all_money >= zakah )
            {
                var z = ( ( all_money * 2.5 ) / 100 ) ;
                all_money = all_money - z ;
                all_zakah += z ;
            }
        }
        $ ( '#silver_money_zakah' ).val ( all_zakah.toFixed ( 3 ) ) ;
        return true ;
        //$ ( '#continue' ).show () ;
    } //) ;

    $ ( '#continue' ).on ( 'click' , function ()
    {
        if ( calculation () )
        {
            $ ( '#silver_zakah_form' ).attr ( 'action' , '/masaref_zakah.php' ) ;
            $ ( '#silver_zakah_form' ).submit () ;
        }
        else
        {
            $ ( '.alert-warning' ).slideDown ( 400 ) ;
            hide_alert () ;
            $ ( '#silver_money_zakah' ).val ( 0 ) ;
        }
    } ) ;
} ) ;
/**
 * End Silver Zakah
 */