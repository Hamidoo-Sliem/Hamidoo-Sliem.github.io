<!DOCTYPE html>
<html>
<head>
    <title></title>
   <link rel="stylesheet" href="kendu/styles/kendo.common.min.css" />
    <link rel="stylesheet" href="kendu/styles/kendo.default.min.css" />
    <link rel="stylesheet" href="kendu/styles/kendo.default.mobile.min.css" />

    <script src="kendu/js/jquery.min.js"></script>
    <script src="kendu/js/jszip.min.js"></script>
    <script src="kendu/js/kendo.all.min.js"></script>
    <script src="json.php"></script>

</head>
<body>

<div id="example">
<button id="export" class="k-button k-button-icontext hidden-on-narrow"><span class="k-icon k-i-excel"></span>Export to Excel</button>
    <div class="hidden-on-narrow" id="configurator"></div>
    <div class="hidden-on-narrow" id="pivotgrid"></div>

    <div class="responsive-message"></div>

    <script>
        $(document).ready(function () {
            var pivotgrid = $("#pivotgrid").kendoPivotGrid({
				
				excel: {
                    fileName: "Docs.xlsx",
                    proxyURL: "https://demos.telerik.com/kendo-ui/service/export",
                    filterable: true
                },
				
                filterable: true,
				sortable: true,
                columnWidth: 120,
                height: 570,
                dataSource: {
                    data: doctors,
                    schema: {
                        model: {
                            fields: {
                                id: { type: "number" },
                                start_time: { type: "string" },
                                end_time: { type: "string" },
                                start_date: { type: "string" },
								end_date: { type: "string" },
								status: { type: "string" }
                                //CategoryName: { field: "Category.CategoryName" }
                            }
                        },
                        cube: {
                            dimensions: {
                                start_time: { caption: "start Time" },
								status: { caption: "Status" },
                               // CategoryName: { caption: "All Categories" },
                                start_date: { caption: "start Date" }
                            },
                          /*  measures: {
                                "Sum": { field: "UnitPrice", format: "{0:c}", aggregate: "sum" },
                                "Average": { field: "UnitPrice", format: "{0:c}", aggregate: "average" }
                            }*/
                        }
                    },
                    columns: [{ name: "start_time", expand: true }, { name: "start_date" } ],
                    rows: [{ name: "status", expand: true }]
                    //measures: ["Sum"]
                }
            }).data("kendoPivotGrid");

            $("#configurator").kendoPivotConfigurator({
                dataSource: pivotgrid.dataSource,
                filterable: true,
                height: 570
            });
			
			 $("#export").click(function() {
                pivotgrid.saveAsExcel();
            });
			
        });
    </script>
    <style>
        #pivotgrid {
            display: inline-block;
            vertical-align: top;
            width: 70%;
        }

        #configurator {
            display: inline-block;
            vertical-align: top;
        }
        #export
        {
            margin: 0 0 10px 1px;
        }
    </style>
</div>





</body>
</html>