<?php
header('Cache-Control: max-age=2592000, public');
header('Expires-Active: On');
header('Expires: Fri, 1 Jan 2500 01:01:01 GMT');
header('Pragma:');
header('Content-type: text/javascript; charset=utf-8');

define('WP_USE_THEMES', true);
require_once( dirname(__FILE__) . '/wp-load.php' );
wp();
global $wpdb;

$docs = $wpdb->get_results("SELECT *,STR_TO_DATE(start_time,'%h:%i %p') AS stime,STR_TO_DATE(end_time,'%h:%i %p') AS etime,STR_TO_DATE('6:30 PM','%h:%i %p') AS sxtime,STR_TO_DATE('8:00 PM','%h:%i %p') AS extime FROM wp_appointment WHERE 
 start_date = '2018-02-22' AND end_date = '2018-02-22' AND docId = '120'");

 $res = json_encode($docs , JSON_UNESCAPED_UNICODE);
 
echo <<< JSON
var doctors = $res;
JSON;

?>